#include <stdio.h>
#include <stdlib.h>

#include "pilha.h"

FILE* abreArquivo(char* nomeDoArquivo)
{
    return fopen(nomeDoArquivo, "r");
}

void fechaArquivo(FILE* fPointer)
{
    fclose(fPointer);
}

void verificaParenteses(Pilha* p, char proximoCaractere)
{
    if(proximoCaractere == '(')
        push(p, proximoCaractere);
    else if(proximoCaractere == ')')
        pop(p);
    else
    {
        if(!isEmpty(p))
        {
            printf("ERRO: elemento encontrado sem fechar parenteses.\n");
            exit(-1);
        }
    }
}

int main()
{
    Pilha p;
    inicializaPilha(&p);

    FILE* pointerFile = abreArquivo("entrada.txt");

    char proximoCaractereASerLido;
    do
    {
        if(fscanf(pointerFile, "%c", &proximoCaractereASerLido) == EOF)
            break;

        verificaParenteses(&p, proximoCaractereASerLido);
    }while(1);

    if(!isEmpty(&p))
    {
        printf("ERRO: Existem parenteses sem fechar.\n");
        exit(-1);
    }

    printf("Funcionou!.\n");

    return 0;
}
