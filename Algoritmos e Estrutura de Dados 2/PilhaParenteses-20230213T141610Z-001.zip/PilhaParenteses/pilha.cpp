#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pilha.h"

void inicializaPilha(Pilha* p)
{
    //inicializa as 100 posi��es do vetor com 0
    memset(p->elementos, 0, sizeof(char) * 100);
    p->topo = -1;
}

void push(Pilha* p, char elemento)
{
    if(p->topo == 99)
    {
        printf("ERRO: pilha cheia.\n");
        exit(-1);
    }

    p->topo++;
    p->elementos[p->topo] = elemento;
}

char pop(Pilha* p)
{
    if(p->topo == -1)
    {
        printf("ERRO: pilha vazia.\n");
        exit(-1);
    }

    char elementoASerRetornado = p->elementos[p->topo];
    p->elementos[p->topo] = 0;
    p->topo--;

    return elementoASerRetornado;
}

bool isEmpty(Pilha* p)
{
    if(p->topo == -1)
        return true;
    return false;
}















