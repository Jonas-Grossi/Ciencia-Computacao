#ifndef _PILHA_H_
#define _PILHA_H_

struct Pilha
{
    char    elementos[100];
    int     topo;
};

void inicializaPilha(Pilha* p);
void push(Pilha* p, char elemento);
char pop(Pilha* p);
bool isEmpty(Pilha* p);

#endif // _PILHA_H_
