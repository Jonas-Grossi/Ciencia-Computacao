
package trabalhoflavio2;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class Arquivo {
public static int acessar =0; //contador de acesso do arquivo
    public static void escreverArq(String texto, String caminho) { //função escrever no arquivo
        acessar++;
        File arquivo = new File(caminho); // cria uma variavek arquivo
        FileWriter fw; // cria um objeto de escrita
        try { //tenta fazer as operaçoes
            fw = new FileWriter(arquivo); //Abre-se o arquivo para escrita, e colocar a condição "(arquivo , TRUE)" só escreve no final
            fw.write(texto); //prepara o texto no arquivo
            fw.flush(); //libera o fluxo de dados
            fw.close(); //fecha arquivo
        } catch (Exception e) { //caso de erro....
            System.out.println("Erro" + e); //msg de erro
        }
    }

    public static String ler(String caminho) { //Função de leitura de arquivo
        
        try {
            acessar++;
            String lido = ""; //variavel de texto lido começa vazia porque nada foi lido
            FileReader fr = new FileReader(caminho); //Abre-se o arquivo para leitura
            try (Scanner arquivoLido = new Scanner(fr)) { //Cria-se um objeto que vai ler
                arquivoLido.useDelimiter("\n"); //Separa-se o que está escrito no arquivo em blocos que são determinados pela qubre de linha
                arquivoLido.next(); //Pula linha '0', fazendo ir para a primeira linha escrita do arquivo.
                while (arquivoLido.hasNext()) { //Se tiver mais conteúdo, ou seja, se não chegou no final
                    lido += arquivoLido.next() + "\n"; //lido recebe o próximo bloco separado (a próxima linha)
                    //  System.out.println(lido); //joga na tela o que foi lido
                }
            }
            return lido;
        } catch (Exception e) {
            return "";
        }
    }

    public static String[] getLinhas(String lido) { //separa linha a linha em um vetor
        String texto = lido;  //texto completo
        String[] arrayTexto = texto.split("\r\n"); //arrayTexto recebe em cada posição o que for separado por '\n' quebra linha
        return arrayTexto;
    }
}
