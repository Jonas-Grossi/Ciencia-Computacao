#ifndef _ARVORE_H_
#define _ARVORE_H_

typedef struct no
{
	int chave;
	no* esq;
    no* dir;
}no;

typedef struct arvore
{
	no* raiz;
}arvore;

#endif
