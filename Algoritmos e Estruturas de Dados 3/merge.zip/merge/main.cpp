#include <stdio.h>
#include <stdlib.h>

void Merge(int* vetor, int p, int q, int r)
{
    int n1 = q - p + 1;
    int n2 = r - q;

    int* L = new int[n1 + 1];
    int* R = new int[n2 + 1];

    for (int i = 0 ; i < n1 ; i++)
        L[i] = vetor[p + i];
    for (int i = 0 ; i < n2 ; i++)
        R[i] = vetor[q + i + 1];
    L[n1] = 9999999;
    R[n2] = 9999999;

    int i = 0;
    int j = 0;
    for (int k = p ; k <= r ; k++)
    {
        if(L[i] <= R[j])
        {
            vetor[k] = L[i];
            i++;
        }else
        {
            vetor[k] = R[j];
            j++;
        }
    }
}

void MergeSort(int* vetor, int p, int r)
{
    int tam = (r - p) + 1;
    int q   = (r + p) / 2;

    if(tam == 1)
    {
        return;
    }else
    {
        MergeSort(vetor, p, q);
        MergeSort(vetor, q + 1, r);
        Merge(vetor, p, q, r);
    }
}

int main()
{
    int vetor[] = {9, 8, 7, 6};
    MergeSort(vetor, 0, 3);

    for(int i = 0 ; i < 4 ; i++)
    {
        printf("%d ", vetor[i]);
    }

    return 0;
}
