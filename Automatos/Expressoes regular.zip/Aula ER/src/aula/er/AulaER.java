
package aula.er;

/**
 *
 * @author Lucas,jonas e caio
 */
public class AulaER {

   
    public static void main(String[] args) {
        ExpressaoRegular ER = new ExpressaoRegular();
        
       
     //ER.confere(ER.DIGITOS, "00051120021");
       
 
        
     //ER.confere(ER.LETRAS, "ASDFEAFdafsafdsf");
        
     //ER.confere(ER.DATA, "5/12/2000");
       
     //ER.confere(ER.REAL, "4.51E21");
        

     //ER.confere(ER.VETOR, "vet[2]");
      
      
      // expressão regular: IDENT (nome de variável, função e classes)
        //ER.confere(ER.VARIAVEL, "Altura1");

        // expressão regular: IDENT (nome de variável, função e classes)
       // ER.confere(ER.VARIAVEL, "1Altura");
        
       //ER.confere(ER.INDEXADOR, "[10]");
        
    //   ER.confere(ER.DESIGNADOR, "matriz[a][2].ponto.x[9][0]");
          ER.confere(ER.DESIGNADOR, "m[4].p.x");
       ER.confere(ER.SOMATORIO, "1+2+SOMA(3,4)");
  //     ER.confere(ER.INTERIOR, "(2,3)");
// ER.confere(ER.SOMA, "SOMA(4,2)");
// ER.confere(ER.TEST, "2+3");       
    ER.confere(ER.IF, "if(a-2 > a)");
       ER.confere(ER.WHILE, "while(a > n)");
         ER.confere(ER.LINHA5, "1+2+SOMA(3,4)-m[4].p.x");
    }
    
}
