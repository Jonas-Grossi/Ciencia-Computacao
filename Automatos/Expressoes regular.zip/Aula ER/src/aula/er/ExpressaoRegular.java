
package aula.er;

/**
 *
 * @author Jonas,Lucas e Caio.
 */
public class ExpressaoRegular {
      
    public String BRANCO, BRANCOS, REAL, DIA, MES , DATA,ANO,VETOR,NOME;  
    public String DIGITO, DIGITOS, FRACAO,SOMATORIO,TEST;
    public String LETRA, LETRAS, QUANTIDADEPARDEA, VARIAVEL,  INTEIRO, EXPONENCIAL;
    public String IDENT;
    public String INTERIORVETOR;   
    public String INDEXADOR;    
    public String DESIGNADOR;
    public String SOMA,LINHA5;
    public String INTERIOR,EXP_MAT,CHAMA_FUNCAO,CONDICIONAL,IF,WHILE ;
    public int a;
    public int b;
    
   
    
    public ExpressaoRegular(){
        BRANCO = "(\\s)";
        BRANCOS = BRANCO + "*";
        
        DIGITO = "([0-9])";
        DIGITOS = "(" + DIGITO + "*)";
                
        LETRA = "([A-Za-z])";
        LETRAS = "(" + LETRA + "*)";
        
        VARIAVEL = "(" + LETRA +"("+LETRA +"|"+ DIGITO+")*)";
        
        INTEIRO = "((-?|\\+?)"+ DIGITOS+")";
        
        EXPONENCIAL = "(E(-?|\\+?)"+DIGITOS+")";         
        FRACAO = "(\\."+ DIGITOS+")";
        REAL = "("+DIGITOS + FRACAO+"?" +EXPONENCIAL+"?)";        
        
        
        
        DIA = "(1|2|3|4|5)"; 
        MES = "(1|2|3|4|5|6|7|8|9|10|11|12)";
        ANO = "([0-9]"+"[0-9]"+"[0-9]"+"[0-9])";
        DATA = DIA + "\\/"+MES+"\\/"+ANO;           
        
        VETOR = VARIAVEL + "\\[((" + DIGITOS + ")+|(" + VARIAVEL +")+)\\]";
        
        
        
        INTERIORVETOR = "(" + INTEIRO + "|" + VARIAVEL + ")";
        //Exemplo:[23], [a3] 
        INDEXADOR = "(\\[" + INTERIORVETOR + "\\])";
        //exemplos: idade, ponto.x, vet[i], vetor[a+b].valor, vetor[i].nome[h].h, matriz[a][2].ponto.x[9][0]
        DESIGNADOR = VARIAVEL + INDEXADOR + "*(\\." + VARIAVEL + INDEXADOR + "*)*";     
        INTERIOR = "\\(" +INTEIRO+ "," + INTEIRO + "\\)";
        //SOMA = VARIAVEL ;
        SOMA = VARIAVEL +INTERIOR;
        //2+3+SOMA(2,4)
       // TEST = (INTEIRO + "\\+"+INTEIRO);
        SOMATORIO =(INTEIRO+ "\\+"+INTEIRO+"\\+"+SOMA);
        
        NOME = "(\\w+" + DIGITOS + ")";
        EXP_MAT = "(((" + NOME + "|" + DIGITOS + "|" + DESIGNADOR + ")" + "(\\+|\\*|\\/|\\-)" + "(" + NOME + "|" + DIGITOS + "|" + DESIGNADOR + "))*" + "(" + NOME + "|" + "[0-9]+" + "|" + DESIGNADOR + "))";
        CHAMA_FUNCAO = "(" + NOME + "\\(" + "((" + NOME + "|" + EXP_MAT + ")" + "\\,)*" + "(" + NOME + "|" + EXP_MAT + ")\\)" + ")" + "|" + NOME + "\\(\\)";
        CONDICIONAL = "((" + EXP_MAT + "|" + CHAMA_FUNCAO + ")" + "\\s*(<|>|<=|>=|==|!=)\\s*" + "(" + EXP_MAT + "|" + CHAMA_FUNCAO + "))";
        IF = "if\\(" + CONDICIONAL + "\\)";
        WHILE = "while\\(" + CONDICIONAL + "\\)";
        LINHA5 = SOMATORIO +"\\-"+ DESIGNADOR;
        
          
}
    public void confere(String exp, String sentenca){
        if((sentenca != null) && !sentenca.isEmpty()){
            if(sentenca.matches(exp)){
                System.out.println("W:'"+ sentenca +"'ACEITA!");
            
            }else{
                System.err.println("W:'"+ sentenca +"'REJEITADA");
            }
            
        }else{
            System.err.println("Sentença vazia");
        }
        
    }
    
}

