package ast.interfaces;

public interface CommandIf extends Command {
	
	Expression getCondition();
	Command getCommandTrue();

}
