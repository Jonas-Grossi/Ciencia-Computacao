package ast.interfaces;

public interface CommandIfElse extends CommandIf {

	Command getCommandFalse();

}
