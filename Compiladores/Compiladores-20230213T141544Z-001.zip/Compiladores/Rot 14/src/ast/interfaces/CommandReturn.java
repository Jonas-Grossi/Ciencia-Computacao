package ast.interfaces;

public interface CommandReturn extends Command {

	Expression getExpression();
	
}
