package ast.interfaces;

public interface CommandWhile extends Command {

	Expression getCondition();
	Command getCommand();
	
}
