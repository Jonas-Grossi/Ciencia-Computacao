package ast.interfaces;

public interface ConstDecl extends Decl {
	
	Type getType();
	NumberConst getValue();
	
}
