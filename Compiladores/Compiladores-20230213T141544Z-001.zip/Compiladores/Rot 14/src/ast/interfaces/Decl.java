package ast.interfaces;

/**
 * @author  Administrador
 */
public interface Decl {
	
	void accept(Visitor visitor);
	Identifier getIdent();
	void setIdent(Identifier ident);

}
