package ast.interfaces;

import java.util.List;

public interface DeclList {
	
	List<Decl> getDecls();
	void accept(Visitor visitor);

    

}
