package ast.interfaces;

public interface Designator extends Expression {

	void accept(Visitor visitor);

}
