package ast.interfaces;

public interface DesignatorArray extends Designator {

	Designator getDesignator();
	Expression getIndex();
	
}
