package ast.interfaces;

public interface DesignatorIdentifier extends Designator {

	Identifier getIdent();
	
}
