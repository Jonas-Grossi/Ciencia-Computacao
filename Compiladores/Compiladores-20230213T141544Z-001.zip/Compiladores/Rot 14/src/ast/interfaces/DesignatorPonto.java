package ast.interfaces;

public interface DesignatorPonto extends Designator {
	
	Designator getLeft();
	Identifier getRight();

}
