package ast.interfaces;

public interface Expression {

	void accept(Visitor visitor);

}
