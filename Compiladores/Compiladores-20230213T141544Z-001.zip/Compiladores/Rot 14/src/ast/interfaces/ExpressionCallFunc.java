package ast.interfaces;

/**
 * @author  Administrador
 */
public interface ExpressionCallFunc extends Expression {
	
	Designator getDesignator();
	ExpressionList getActPars();
	void setDesignator(Designator designator);
	void setActPars(ExpressionList actPars);

}
