package ast.interfaces;

import java.util.List;

public interface ExpressionList {
	
	List<Expression> getExpressions();
	void accept(Visitor visitor);

}
