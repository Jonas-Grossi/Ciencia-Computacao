package ast.interfaces;

public interface Factory {
	
	BinaryOperation createBinaryOperation(int code, Expression operand1, Expression operand2);
	Block createBlock();
	CharConst createCharConst(char ch);
	ClassDecl createClassDecl(Identifier ident, DeclList declList);
	CommandAssign createCommandAssign(Designator designator, Expression expression);
	CommandCallFunc createCommandCallFunc(Designator designator, ExpressionList expressionList);
	CommandIf createCommandIf(Expression condition, Command command);
	CommandIfElse createCommandIfElse(Expression condition, Command command1, Command command2);	
	CommandReturn createCommandReturn(Expression expr);
	CommandWhile createCommandWhile(Expression condition, Command command);
	ConstDecl createConstDecl(Type type, Identifier ident, NumberConst value);
	DeclList createDeclList();
	DesignatorArray createDesignatorArray(Designator desig, Expression index);
	DesignatorIdentifier createDesignatorIdentifier(Identifier ident);
	DesignatorPonto createDesignatorPonto(Designator desig, Identifier ident);
	ExpressionCallFunc createExpressionCallFunc(Designator designator, ExpressionList expList);
	ExpressionList createExpressionList();
	FloatNumber createFloatNumber(float f);
	Identifier createIdentifier(String name);
	IntegerNumber createIntegerNumber(int i);
	MethodDecl createMethodDecl(Type type, Identifier ident,
			DeclList paramList, DeclList varList, Block block);
	New createNew(Identifier ident);
	NewArray createNewArray(Identifier ident, Expression expr);
	Program createProgram(Identifier ident, DeclList initDeclList, DeclList methodDeclList);
	Type createType(Identifier ident);
	TypeArray createTypeArray(Identifier ident);
	UnaryOperation createUnaryOperation(int code, Expression operand);
	VarDecl createVarDecl(Type type, Identifier ident);

}
