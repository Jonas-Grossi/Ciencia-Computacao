package ast.interfaces;

public interface FloatNumber extends NumberConst, Expression {

	void accept(Visitor visitor);
	float getValue();

}
