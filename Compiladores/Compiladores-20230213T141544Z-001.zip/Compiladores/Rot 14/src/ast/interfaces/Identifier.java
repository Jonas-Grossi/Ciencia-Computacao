package ast.interfaces;

public interface Identifier {
	
	String getName();
	void accept(Visitor visitor);

}
