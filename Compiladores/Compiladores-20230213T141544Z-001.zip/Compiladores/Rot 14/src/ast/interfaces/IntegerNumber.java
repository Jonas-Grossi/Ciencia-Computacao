package ast.interfaces;

public interface IntegerNumber extends NumberConst, Expression {

	void accept(Visitor visitor);
	int getValue();

}
