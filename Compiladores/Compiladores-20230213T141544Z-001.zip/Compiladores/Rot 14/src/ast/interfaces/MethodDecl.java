package ast.interfaces;

/**
 * @author  Administrador
 */
public interface MethodDecl extends Decl {
	
	void accept(Visitor visitor);
	Type getReturnType();
	DeclList getParamList();
	DeclList getVarList();
	void setParamList(DeclList paramList);
	void setVarList(DeclList declList);
	Block getBlock();
	void setBlock(Block block);
	
}
