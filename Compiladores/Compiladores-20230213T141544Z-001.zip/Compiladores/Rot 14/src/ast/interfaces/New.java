package ast.interfaces;

public interface New extends Expression {
	
	Identifier getIdent();

}
