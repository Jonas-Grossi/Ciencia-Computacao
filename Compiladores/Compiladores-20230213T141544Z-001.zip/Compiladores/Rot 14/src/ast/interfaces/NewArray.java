package ast.interfaces;

public interface NewArray extends New {
	
	Expression getExpression();
	
}
