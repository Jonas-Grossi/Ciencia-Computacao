package ast.interfaces;

public interface NumberConst {
	
	void accept(Visitor visitor);

}
