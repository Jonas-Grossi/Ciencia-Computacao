package ast.interfaces;

public interface Operation extends Expression {

	int getCode();
	
}
