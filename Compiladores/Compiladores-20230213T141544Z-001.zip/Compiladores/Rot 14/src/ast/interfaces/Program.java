package ast.interfaces;

public interface Program {
	
	void accept(Visitor visitor);
	Identifier getIdent();
	DeclList getInitDeclList();
	DeclList getMethodDeclList();
	
}
