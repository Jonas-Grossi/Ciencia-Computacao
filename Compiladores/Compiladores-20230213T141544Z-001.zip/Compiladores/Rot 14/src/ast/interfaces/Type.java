package ast.interfaces;

import semantic.interfaces.SemanticType;

public interface Type {

	void accept(Visitor visitor);
	Identifier getIdent();
	
        SemanticType getSemanticType();
        void setSemanticType(SemanticType t);
}
