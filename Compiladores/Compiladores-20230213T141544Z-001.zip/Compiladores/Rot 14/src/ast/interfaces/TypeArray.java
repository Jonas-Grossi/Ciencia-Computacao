package ast.interfaces;

public interface TypeArray extends Type {
	
}
