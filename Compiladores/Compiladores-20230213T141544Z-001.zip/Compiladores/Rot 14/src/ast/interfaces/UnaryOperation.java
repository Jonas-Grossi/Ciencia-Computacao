package ast.interfaces;

public interface UnaryOperation extends Operation {

	Expression getOperand();
	
}
