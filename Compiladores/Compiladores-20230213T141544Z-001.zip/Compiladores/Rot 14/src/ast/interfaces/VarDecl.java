package ast.interfaces;

public interface VarDecl extends Decl {

	Type getType();
	
}
