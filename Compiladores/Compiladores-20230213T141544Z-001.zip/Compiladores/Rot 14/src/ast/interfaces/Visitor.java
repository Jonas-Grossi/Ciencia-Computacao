package ast.interfaces;

public interface Visitor {
	
	void visitBinaryOperation(Operation operation, int i);
	void visitBlock(Block block, int i);
	void visitCharConst(CharConst c, int i);
	void visitClassDecl(ClassDecl classDecl, int i);
	void visitCommandAssign(CommandAssign assignCommand, int i);
	void visitCommandCallFunc(CommandCallFunc callFuncCommand, int i);
	void visitCommandIf(CommandIf ifCommand, int i);
	void visitCommandIfElse(CommandIfElse ifElseCommand, int i);
	void visitCommandReturn(CommandReturn returnCommand, int i);
	void visitCommandWhile(CommandWhile whileCommand, int i);
	void visitConstDecl(ConstDecl constDecl, int i);
	void visitDeclList(DeclList declList, int i);
	void visitDesignatorArray(DesignatorArray designatorArray, int i);
	void visitDesignatorIdentifier(DesignatorIdentifier designatorIdentifier, int i);
	void visitDesignatorPonto(DesignatorPonto designatorPonto, int i);
	void visitExpressionDesignator(
			ExpressionCallFunc expressionDesignator, int i);
	void visitExpressionList(ExpressionList expressionList, int i);
	void visitFloatNumber(FloatNumber floatNumber);
	void visitIdentifier(Identifier identifier, int i);
	void visitIntegerNumber(IntegerNumber integerNumber, int i);
	void visitMethodDecl(MethodDecl methodDecl, int i);
	void visitNew(New n, int i);
	void visitNewArray(NewArray na, int i);
	void visitProgram(Program program, int i);
	void visitType(Type type, int i);
	void visitTypeArray(TypeArray typeArray, int i);
	void visitUnaryOperation(Operation operation, int i);
	void visitVarDecl(VarDecl varDecl, int i);

}
