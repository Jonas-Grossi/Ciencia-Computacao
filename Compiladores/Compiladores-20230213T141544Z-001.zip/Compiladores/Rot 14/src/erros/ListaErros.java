package erros;

import java.util.ArrayList;

public class ListaErros {

	class Erro {
		int linha, coluna;
		String texto;
		Erro(int linha, int coluna, String texto) {
			this.linha = linha;
			this.coluna = coluna;
			this.texto = texto;
		}
	}
	
	private ArrayList<Erro> erros;
	private ArrayList<String> outros;

	public ListaErros() {
		erros = new ArrayList<Erro>();
		outros = new ArrayList<String>(); 
	}
	
	public int tamanho() {
		return erros.size() + outros.size();
	}
	
	public void defErro(int linha, int coluna, String texto) {
		erros.add(new Erro(linha, coluna, texto));
	}
	
	public void defErro(int linha, int coluna) {
		erros.add(new Erro(linha, coluna, null));
	}
	
	public void defErro(String texto) {
		for (int i = erros.size() - 1; i >= 0; --i) {
			Erro e = erros.get(i);
			if (e.texto == null) {
				e.texto = texto;
				return;
			}
		}
		outros.add(texto);
	}
	
	public void dump() {
		for (int i = 0; i < erros.size(); ++i) {
			Erro e = erros.get(i);
			String s = e.texto;
			if (s == null) {
				s = "";
			}
			System.out.println(
					"linha=" + (e.linha + 1)
					+ " coluna=" + (e.coluna + 1)
					+ "  " + s);
		}
		if (outros.size() > 0) {
			for (String s : outros) {
				System.out.println("linha=???" + " coluna=???" + "  " + s);
			}
		}
	}
	
}
