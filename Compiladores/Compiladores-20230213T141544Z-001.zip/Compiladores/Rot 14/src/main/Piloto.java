package main;

import java.io.FileInputStream;
import semantic.interfaces.*;
import semantic.impl.SemanticFactory;

import erros.ListaErros;
import ast.interfaces.Program;
import scanner.Scanner;
import parser.Parser;

public class Piloto {

    public static void main(String[] args) throws Exception {
        FileInputStream in = new FileInputStream("teste.txt");
        ListaErros erros = new ListaErros();
        Scanner scanner = new Scanner(in, erros);
        Parser parser = new Parser(scanner, new ast.impl.Factory(),
                new semantic.impl.SemanticFactory());
        try {
            Object obj = parser.parse().value;
            if (obj != null) {
                Program p = (Program) obj;
                PrinterVisitor pv = new PrinterVisitor(System.out);
                p.accept(pv);

                if (erros.tamanho() == 0) {
                    System.out.println("Arquivo sem erros de sintaxe!");
                    teste();
                } else {
                    System.out.println("Erros encontrados:");
                    erros.dump();
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void teste() {
        //cria uma fabrica semantica	
        SemanticFactory fabricaSemantica = new SemanticFactory();

        //cria uma tabela de simbolos e empilha um ambiente
        SymbolTable table = fabricaSemantica.createSymbolTable();
        table.pushEnvironment();

        //linha 1
        SemanticType tInt = table.getIntegerType();
        table.addSymbolConstant("size", tInt, new Integer(10));

        //linha 3
        Symbol_Class tClasse = table.addSymbolClass("Casa");
        semantic.interfaces.Environment e = new semantic.impl.Environment();//table.pushEnvironment();

        //linha 4
        SemanticType tVetor = fabricaSemantica.createArrayType(tInt);
        e.addSymbolVariable("pos", tVetor);

        //Environment e1 = table.popEnvironment();
        ((ClassType) tClasse.getSemanticType()).setEnvironment(e);

        SemanticType tReturn = table.getVoidType();
        MethodType tFuncao = fabricaSemantica.createMethodType(tReturn);
        tFuncao.getParams().add(tInt);
        tFuncao.getParams().add(tInt);
        table.addSymbolMethod("main", tFuncao);
        //inicia-se um novo ambiente e registrar as “variáveis” 
        table.pushEnvironment();
        table.addSymbolVariable("a", tInt);
        table.addSymbolVariable("b", tInt);
        table.addSymbolVariable("x", tInt);

        //linha 11, verifica se as variáveis foram declaradas
        if (table.getSymbol("x") == null) {
            System.out.println("Símbolo não encontrado: x");
        }
        if (table.getSymbol("a") == null) {
            System.out.println("Símbolo não encontrado: a");
        }
        if (table.getSymbol("b") == null) {
            System.out.println("Símbolo não encontrado: b");
        }
        table.popEnvironment();

    }

}
