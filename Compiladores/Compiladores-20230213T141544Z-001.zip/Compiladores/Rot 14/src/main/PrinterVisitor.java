package main;

import java.io.PrintStream;

import parser.SymbolCodes;
import ast.interfaces.*;

public class PrinterVisitor
extends VisitorStub
implements Visitor {

	private PrintStream out;
		
	public PrinterVisitor(PrintStream out) {
		this.out = out;
	}
	
	public void visitProgram(Program program, int i) {
		if (i == 0) {
			out.println("program " + program.getIdent());
		} else if (i == 1) {
			out.println("{");
		} else if (i == 2) {
			out.println("}");
		}
	}
	
	public void visitIdentifier(Identifier ident, int i) {
		out.print(ident.getName());
	}

	public void visitTypeArray(TypeArray typeArray, int i) {
		if (i == 1) {
			out.print("[]");
		}
	}
	
	public void visitVarDecl(VarDecl varDecl, int i) {
		if (i == 1) {
			out.print(" ");
		} else if (i == 2) {
			out.println(";");
		}
	}

	public void visitConstDecl(ConstDecl constDecl, int i) {
		if (i == 0) {
			out.print("final ");
		} else if (i == 1) {
			out.print(" ");
		} else if (i == 2) {
			out.print("= ");
		} else if (i == 3) {
			out.println(";");
		}
	}

	public void visitClassDecl(ClassDecl classDecl, int i) {
		if (i == 0) {
			out.print("class ");
		} else if (i == 1) {
			out.println("{");
		} else if (i == 2) {
			out.println("}");
		}
	}

	public void visitMethodDecl(MethodDecl methodDecl, int i) {
		if (i == 1) {
			out.print(" ");
		} else if (i == 2) {
			out.print("(");
		} else if (i == 3) {
			out.println(")");
		}
	}

	public void visitIntegerNumber(IntegerNumber inteiro, int i) {
		out.print(inteiro.getValue());
	}

	public void visitFloatNumber(FloatNumber pontoFlutuante, int i) {
		out.print(pontoFlutuante.getValue());
	}

	public String codeToString(int code) {
		String s = "";
		switch (code) {
		case SymbolCodes.DIF:
			s = "!=";
			break;
		case SymbolCodes.DIVIDIR:
			s = "/";
			break;
		case SymbolCodes.IGUALIGUAL:
			s = "==";
			break;
		case SymbolCodes.MAIOROUIGUAL:
			s = ">=";
			break;
		case SymbolCodes.MAIORQUE:
			s = ">";
			break;
		case SymbolCodes.MAIS:
			s = "+";
			break;
		case SymbolCodes.MENOROUIGUAL:
			s = "<=";
			break;
		case SymbolCodes.MENORQUE:
			s = "<";
			break;
		case SymbolCodes.MENOS:
			s = "-";
			break;
		case SymbolCodes.MOD:
			s = "%";
			break;
		case SymbolCodes.VEZES:
			s = "*";
			break;
		}
		return s;
	}
	
	public void visitDesignatorPonto(DesignatorPonto d, int i) {
		if (i == 1) {
			out.print(".");
		}
	}
	
	public void visitDesignatorArray(DesignatorArray d, int i) {
		if (i == 1) {
			out.print("[");
		} else if (i == 2) {
			out.print("]");
		}
	}
	
	public void visitExpressionList(ExpressionList exprList, int i) {
		if (i > 0 && i < exprList.getExpressions().size()) {
			out.print(", ");
		}
	}
	
	public void visitExpressionDesignator(ExpressionCallFunc ed, int i) {
		if (i == 1) {
			out.print("(");
		} else if (i == 2) {
			out.print(")");
		}
	}
	
	public void visitCommandCallFunc(CommandCallFunc cfc, int i) {
		if (i == 1) {
			out.print("(");
		} else if (i == 2) {
			out.println(");");
		}
	}
	
	public void visitCommandAssign(CommandAssign ac, int i) {
		if (i == 1) {
			out.print(" = ");
		} else if (i == 2) {
			out.println(";");
		}
	}
	
	public void visitBlock(Block b, int i) {
		if (i == 0) {
			out.println("{");
		} else if (i > b.getCommandList().size()) {
			out.println("}");
		} 
		
	}

	public void visitBinaryOperation(Operation operation, int i) {
		if (i == 0) {
			out.print("(");
		} else if (i == 1) {
			out.print(codeToString(operation.getCode()));
		} else if (i == 2) {
			out.print(")");
		} 
	}

	public void visitUnaryOperation(Operation operation, int i) {
		if (i == 0) {
			out.print("(" + codeToString(operation.getCode()));
		} else if (i == 1) {
			out.print(")");
		} 
	}
	
	public void visitNew(New n, int i) {
		if (i == 0) {
			out.print("new ");
		}
	}
	
	public void visitNewArray(NewArray na, int i) {
		if (i == 0) {
			out.print("new ");
		} else if (i == 1) {
			out.print("[");
		} else if (i == 2) {
			out.print("]");
		}
	}

	public void visitCommandIf(CommandIf c, int i) {
		if (i == 0) {
			out.print("if ");
		} else if (i == 1) {
			out.print(" ");
		}
	}

	public void visitCommandIfElse(CommandIfElse c, int i) {
		if (i == 0) {
			out.print("if ");
		} else if (i == 1) {
			out.print(" ");
		} else if (i == 2) {
			out.print("else ");
		}
	}

	public void visitCommandWhile(CommandWhile c, int i) {
		if (i == 0) {
			out.print("while ");
		} else if (i == 1) {
			out.print(" ");
		}
	}

	public void visitCharConst(CharConst c, int i) {
		out.print("\'" + c.getChar() + "\'");
	}
}
