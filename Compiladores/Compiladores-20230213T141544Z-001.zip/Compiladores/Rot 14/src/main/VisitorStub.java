package main;

import ast.interfaces.*;

public class VisitorStub implements Visitor {

	public void visitCommandAssign(CommandAssign assignCommand, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitBinaryOperation(Operation operation, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitBlock(Block block, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitCommandCallFunc(CommandCallFunc callFuncCommand, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitClassDecl(ClassDecl classDecl, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitConstDecl(ConstDecl constDecl, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitDeclList(DeclList declList, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitDesignatorArray(DesignatorArray designatorArray, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitDesignatorIdentifier(
			DesignatorIdentifier designatorIdentifier, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitDesignatorPonto(DesignatorPonto designatorPonto, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitExpressionDesignator(
			ExpressionCallFunc expressionDesignator, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitExpressionList(ExpressionList expressionList, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitFloatNumber(FloatNumber floatNumber) {
		// TODO Auto-generated method stub
		
	}

	public void visitIdentifier(Identifier identifier, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitCommandIf(CommandIf ifCommand, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitCommandIfElse(ast.interfaces.CommandIfElse ifElseCommand,
			int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitIntegerNumber(IntegerNumber integerNumber, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitMethodDecl(MethodDecl methodDecl, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitProgram(Program program, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitCommandReturn(ast.interfaces.CommandReturn returnCommand,
			int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitType(Type type, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitTypeArray(TypeArray typeArray, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitUnaryOperation(Operation operation, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitVarDecl(VarDecl varDecl, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitCommandWhile(ast.interfaces.CommandWhile whileCommand,
			int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitNew(New n, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitNewArray(NewArray na, int i) {
		// TODO Auto-generated method stub
		
	}

	public void visitCharConst(CharConst c, int i) {
		// TODO Auto-generated method stub
		
	}


}
