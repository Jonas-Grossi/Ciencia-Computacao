package semantic.impl;

public class ArrayType
extends SemanticType
implements semantic.interfaces.ArrayType {

	private semantic.interfaces.SemanticType innerType;
	
	public ArrayType(semantic.interfaces.SemanticType innerType) {
		this.innerType = innerType;
	}
	
	public semantic.interfaces.SemanticType getInnerType() {
		return innerType;
	}
	
	public boolean isArray() {
		return true;
	}

}
