package semantic.impl;

public class CharType
extends ScalarType
implements semantic.interfaces.CharType {

	public boolean isChar() {
		return true;
	}

}
