package semantic.impl;

public class ClassType
extends SemanticType
implements semantic.interfaces.ClassType {

	private semantic.interfaces.Environment env;
	
	public ClassType() {
		env = new Environment();
	}

	public semantic.interfaces.Environment getEnvironment() {
		return env;
	}
	
	public void setEnvironment(semantic.interfaces.Environment env) {
		this.env = env;
	}
	
	public boolean isClass() {
		return true;
	}
	
	public boolean isScalar() {
		return false;
	}

}
