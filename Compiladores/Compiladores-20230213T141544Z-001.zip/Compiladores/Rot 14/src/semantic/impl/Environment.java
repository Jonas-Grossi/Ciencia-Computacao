package semantic.impl;

import java.util.HashMap;

public class Environment
        implements semantic.interfaces.Environment {

    private HashMap<String, semantic.interfaces.SemanticSymbol> map;
    private int level, cont;

    public Environment() {
        map = new HashMap<String, semantic.interfaces.SemanticSymbol>();
        cont = 0;
        level = -1;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public semantic.interfaces.Symbol_Variable addSymbolVariable(String name, semantic.interfaces.SemanticType type) {
        if (getSymbol(name) != null) {
            return null;
        }
        semantic.interfaces.Symbol_Variable s = new Symbol_Variable(name, type, level, cont);
        ++cont;
        map.put(name, s);
        return s;
    }

    public semantic.interfaces.Symbol_Class addSymbolClass(
            String name, semantic.interfaces.ClassType type) {
        if (getSymbol(name) != null) {
            return null;
        }
        semantic.interfaces.Symbol_Class s = new Symbol_Class(name, type);
        map.put(name, s);
        return s;
    }

    public semantic.interfaces.Symbol_Method addSymbolMethod(
            String name, semantic.interfaces.MethodType type) {
        if (getSymbol(name) != null) {
            return null;
        }
        semantic.interfaces.Symbol_Method s = new Symbol_Method(name, type);
        map.put(name, s);
        return s;
    }

    public semantic.interfaces.Symbol_Constant addSymbolConstant(String name,
            semantic.interfaces.SemanticType type, Object value) {
        if (getSymbol(name) != null) {
            return null;
        }
        semantic.interfaces.Symbol_Constant s = new Symbol_Constant(name, type, value);
        map.put(name, s);
        return s;
    }

    public semantic.interfaces.SemanticSymbol getSymbol(String name) {
        return map.get(name);
    }

    public int numVariaveis() {
        return cont;
    }

}
