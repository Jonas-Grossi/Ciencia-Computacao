package semantic.impl;

public class FloatType
extends ScalarType 
implements semantic.interfaces.FloatType {

	public boolean isFloat() {
		return true;
	}

}
