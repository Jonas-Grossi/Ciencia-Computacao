package semantic.impl;

public class IntegerType
extends ScalarType
implements semantic.interfaces.IntegerType {

	public boolean isInteger() {
		return true;
	}

}
