package semantic.impl;

import java.util.ArrayList;
import java.util.List;

public class MethodType
extends SemanticType
implements semantic.interfaces.MethodType {

	private semantic.interfaces.SemanticType returnType;
	private List<semantic.interfaces.SemanticType> params;
	
	public MethodType(semantic.interfaces.SemanticType returnType) {
		this.returnType = returnType;
		this.params = new ArrayList<semantic.interfaces.SemanticType>();
	}
	
	public MethodType(semantic.interfaces.SemanticType returnType,
			List<semantic.interfaces.SemanticType> params) {
		this.returnType = returnType;
		this.params = params;
	}

	public List<semantic.interfaces.SemanticType> getParams() {
		return params;
	}

	public semantic.interfaces.SemanticType getReturnType() {
		return returnType;
	}
	
	public boolean isMethod() {
		return true;
	}

}
