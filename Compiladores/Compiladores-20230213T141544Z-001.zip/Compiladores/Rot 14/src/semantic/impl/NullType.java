package semantic.impl;

public class NullType
extends ClassType
implements semantic.interfaces.NullType {

	public boolean isNull() {
		return true;
	}

}
