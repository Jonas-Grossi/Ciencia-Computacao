package semantic.impl;

public class ScalarType extends ClassType {
	
	public boolean isScalar() {
		return true;
	}

}
