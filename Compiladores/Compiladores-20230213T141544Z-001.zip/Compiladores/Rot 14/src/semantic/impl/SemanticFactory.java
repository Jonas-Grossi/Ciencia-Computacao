package semantic.impl;

public class SemanticFactory implements semantic.interfaces.SemanticFactory {
	
	public semantic.interfaces.ArrayType createArrayType(semantic.interfaces.SemanticType innerType) {
		return new ArrayType(innerType);
	}
	
	public semantic.interfaces.ClassType createClassType() {
		return new ClassType();
	}
	
	public semantic.interfaces.MethodType createMethodType(
			semantic.interfaces.SemanticType returnType) {
		return new MethodType(returnType);
	}

	public semantic.interfaces.SymbolTable createSymbolTable() {
		return new SymbolTable();
	}

}
