package semantic.impl;

import semantic.interfaces.SemanticType;

public class SemanticSymbol
implements semantic.interfaces.SemanticSymbol {

	private String name;
	private SemanticType type;
	
	public SemanticSymbol(String name, SemanticType type) {
		this.name = name;
		this.type = type;
	}
	
	public String getName() {
		return name;
	}
	
	public SemanticType getSemanticType() {
		return type;
	}

	public boolean isSymbolConstant() {
		return false;
	}
	
	public boolean isSymbolVariable() {
		return false;
	}
	
	public boolean isSymbolClass() {
		return false;
	}
	
	public boolean isSymbolMethod() {
		return false;
	}

}
