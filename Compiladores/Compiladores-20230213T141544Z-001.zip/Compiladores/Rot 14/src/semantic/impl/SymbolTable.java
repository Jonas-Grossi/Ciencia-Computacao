package semantic.impl;

import java.util.Stack;

public class SymbolTable implements semantic.interfaces.SymbolTable {

    private Stack<semantic.interfaces.Environment> stack;

    private semantic.interfaces.CharType charType = new CharType();
    private semantic.interfaces.VoidType voidType = new VoidType();
    private semantic.interfaces.IntegerType integerType = new IntegerType();
    private semantic.interfaces.FloatType floatType = new FloatType();
    private semantic.interfaces.NullType nullType = new NullType();

    /**
     * Construtor.
     */
    public SymbolTable() {
        stack = new Stack<semantic.interfaces.Environment>();
        pushEnvironment();
        addSymbolClass("void", voidType);
        addSymbolClass("int", integerType);
        addSymbolClass("float", floatType);
        addSymbolClass("char", charType);
        addSymbolClass("null", nullType);
    }

    /**
     * Empilha ambiente.
     */
    public void pushEnvironment() {
        semantic.interfaces.Environment e = new Environment();
        e.setLevel(stack.size());
        stack.push(e);
    }

    /**
     * Desempilha ambiente.
     *
     * @return Ambiente desempilhado.
     */
    public semantic.interfaces.Environment popEnvironment() {
        return stack.pop();
    }

    /**
     * Procura s�mbolo, dado identificador. Procura primeiro nos ambientes dos
     * n�veis superiores.
     *
     * @param name Identificador do s�mbolo.
     * @return S�mbolo encontrado; ou null, se n�o encontrar.
     */
    public semantic.interfaces.SemanticSymbol getSymbol(String name) {
        for (int i = stack.size() - 1; i >= 0; --i) {
            semantic.interfaces.Environment env = stack.get(i);
            semantic.interfaces.SemanticSymbol t = env.getSymbol(name);
            if (t != null) {
                return t;
            }
        }
        return null;
    }

    /**
     * Adiciona declara��o de vari�vel no ambiente corrente.
     *
     * @param name Nome da vari�vel.
     * @param type Tipo da vari�vel.
     * @return S�mbolo adicionado; ou null, se o identificador j� estiver sendo
     * usado.
     */
    public semantic.interfaces.Symbol_Variable addSymbolVariable(String name, semantic.interfaces.SemanticType type) {
        semantic.interfaces.Environment env = stack.peek();
        return env.addSymbolVariable(name, type);
    }

    /**
     * Adiciona declara��o de m�todo no ambiente corrente.
     *
     * @param name Nome do m�todo.
     * @param type Tipo de retorno do m�todo.
     * @return S�mbolo adicionado; ou null, se o identificador j� estiver sendo
     * usado.
     */
    public semantic.interfaces.Symbol_Method addSymbolMethod(String name, semantic.interfaces.SemanticType type) {
        semantic.interfaces.Environment env = stack.peek();
        semantic.interfaces.MethodType m = new MethodType(type);
        return env.addSymbolMethod(name, m);
    }

    /**
     * Adiciona declara��o de classe/tipo no ambiente corrente.
     *
     * @param name Nome da classe.
     * @param type Tipo associado.
     * @return S�mbolo adicionado; ou null, se o identificador j� estiver sendo
     * usado.
     */
    public semantic.interfaces.Symbol_Class addSymbolClass(String name, semantic.interfaces.ClassType type) {
        semantic.interfaces.Environment env = stack.peek();
        return env.addSymbolClass(name, type);
    }

    /**
     * Adiciona declara��o de classe/tipo no ambiente corrente, para os casos em
     * que uma nova classe est� sendo criada.
     *
     * @param name Nome da classe.
     * @return S�mbolo adicionado; ou null, se o identificador j� estiver sendo
     * usado.
     */
    public semantic.interfaces.Symbol_Class addSymbolClass(String name) {
        semantic.interfaces.Environment env = stack.peek();
        semantic.interfaces.ClassType type = new ClassType();
        return env.addSymbolClass(name, type);
    }

    public semantic.interfaces.Symbol_Constant addSymbolConstant(String name,
            semantic.interfaces.SemanticType type, Object value) {
        semantic.interfaces.Environment env = stack.peek();
        return env.addSymbolConstant(name, type, value);
    }

    /**
     * Tipo escalar "char".
     *
     * @return Refer�ncia ao tipo escalar, para ser usado em declara��es.
     */
    public semantic.interfaces.CharType getCharType() {
        return charType;
    }

    /**
     * Tipo escalar "void".
     *
     * @return Refer�ncia ao tipo escalar, para ser usado em declara��es.
     */
    public semantic.interfaces.VoidType getVoidType() {
        return voidType;
    }

    /**
     * Tipo escalar "int".
     *
     * @return Refer�ncia ao tipo escalar, para ser usado em declara��es.
     */
    public semantic.interfaces.IntegerType getIntegerType() {
        return integerType;
    }

    /**
     * Tipo escalar "float".
     *
     * @return Refer�ncia ao tipo escalar, para ser usado em declara��es.
     */
    public semantic.interfaces.FloatType getFloatType() {
        return floatType;
    }

    /**
     * Tipo escalar "null".
     *
     * @return Refer�ncia ao tipo escalar.
     */
    public semantic.interfaces.NullType getNullType() {
        return nullType;
    }

}
