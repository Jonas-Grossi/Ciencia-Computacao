package semantic.impl;

public class Symbol_Class
extends SemanticSymbol
implements semantic.interfaces.Symbol_Class {
	
	public Symbol_Class(String name, semantic.interfaces.SemanticType type) {
		super(name, type);
	}
	
	public boolean isSymbolClass() {
		return true;
	}
	
}
