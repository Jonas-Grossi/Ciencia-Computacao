package semantic.impl;

public class Symbol_Constant
extends SemanticSymbol
implements semantic.interfaces.Symbol_Constant {
	
	private Object value;
	
	public Symbol_Constant(String name, semantic.interfaces.SemanticType type, Object value) {
		super(name, type);
		this.value = value;
	}
	
	public boolean isSymbolConstant() {
		return true;
	}

	public Object getValue() {
		return value;
	}

}
