package semantic.impl;

public class Symbol_Method
extends SemanticSymbol
implements semantic.interfaces.Symbol_Method {
	
	public Symbol_Method(String name, semantic.interfaces.SemanticType type) {
		super(name, type);
	}

	public boolean isSymbolMethod() {
		return true;
	}

}
