package semantic.impl;

public class VoidType
extends ScalarType
implements semantic.interfaces.VoidType {

	public boolean isVoid() {
		return true;
	}

}
