package semantic.interfaces;

public interface ArrayType
extends SemanticType {
	
	public SemanticType getInnerType();

}
