package semantic.interfaces;

public interface CharType extends ScalarType {

}
