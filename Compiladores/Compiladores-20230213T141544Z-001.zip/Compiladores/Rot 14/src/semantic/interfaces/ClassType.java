package semantic.interfaces;

public interface ClassType extends SemanticType {

	public Environment getEnvironment();
	
	public void setEnvironment(Environment env);
	
	public boolean isClass();
	
	public boolean isScalar();

}
