
package semantic.interfaces;

public interface Environment {
	
	public void setLevel(int level);
	
	public Symbol_Variable addSymbolVariable(
			String name, SemanticType type);
	
	public Symbol_Class addSymbolClass(
			String name, ClassType type);
	
	public Symbol_Constant addSymbolConstant(
			String name, SemanticType type, Object value);
	
	public Symbol_Method addSymbolMethod(
			String name, MethodType type);
	
	public SemanticSymbol getSymbol(String name);
	
	public int numVariaveis();
	
}