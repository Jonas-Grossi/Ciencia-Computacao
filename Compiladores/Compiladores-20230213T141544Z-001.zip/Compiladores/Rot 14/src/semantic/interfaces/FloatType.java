package semantic.interfaces;

public interface FloatType
extends ScalarType {

}
