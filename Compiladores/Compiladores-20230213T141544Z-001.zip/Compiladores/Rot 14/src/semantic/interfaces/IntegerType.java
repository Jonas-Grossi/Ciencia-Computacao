package semantic.interfaces;

public interface IntegerType
extends ScalarType {

}
