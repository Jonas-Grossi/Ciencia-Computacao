package semantic.interfaces;

public interface NullType
extends ClassType {

}
