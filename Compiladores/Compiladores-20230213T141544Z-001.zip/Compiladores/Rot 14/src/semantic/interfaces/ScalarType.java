package semantic.interfaces;

public interface ScalarType extends ClassType {

}
