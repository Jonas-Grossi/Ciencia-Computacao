package semantic.interfaces;

public interface SemanticFactory {

	public ArrayType createArrayType(SemanticType innerType);

	public ClassType createClassType();

	public MethodType createMethodType(SemanticType returnType);

	public SymbolTable createSymbolTable();

}