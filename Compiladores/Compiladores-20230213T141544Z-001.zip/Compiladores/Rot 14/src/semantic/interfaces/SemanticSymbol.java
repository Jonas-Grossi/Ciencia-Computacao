package semantic.interfaces;

public interface SemanticSymbol {

	String getName();
	
	SemanticType getSemanticType();
	
	boolean isSymbolConstant();
	
	boolean isSymbolVariable();
	
	boolean isSymbolClass();
	
	boolean isSymbolMethod();

}
