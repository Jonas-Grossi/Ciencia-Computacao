package semantic.interfaces;

public interface SymbolTable {
	
	/**
	 * Empilha ambiente.
	 */
	public void pushEnvironment();
	
	/**
	 * Desempilha ambiente.
	 * @return Ambiente desempilhado.
	 */
	public Environment popEnvironment();

	/**
	 * Procura s�mbolo, dado identificador.
	 * Procura primeiro nos ambientes dos n�veis superiores.
	 * @param name Identificador do s�mbolo.
	 * @return S�mbolo encontrado; ou null, se n�o encontrar.
	 */
	public SemanticSymbol getSymbol(String name);

	/**
	 * Adiciona declara��o de vari�vel no ambiente corrente.
	 * @param name Nome da vari�vel.
	 * @param type Tipo da vari�vel.
	 * @return S�mbolo adicionado; ou null, se o identificador j� estiver sendo usado.
	 */
	public Symbol_Variable addSymbolVariable(String name, SemanticType type);
	
	/**
	 * Adiciona declara��o de m�todo no ambiente corrente.
	 * @param name Nome do m�todo.
	 * @param type Tipo de retorno do m�todo.
	 * @return S�mbolo adicionado; ou null, se o identificador j� estiver sendo usado.
	 */
	public Symbol_Method addSymbolMethod(String name, SemanticType type);
	
	/**
	 * Adiciona declara��o de classe/tipo no ambiente corrente.
	 * @param name Nome da classe.
	 * @param type Tipo associado.
	 * @return S�mbolo adicionado; ou null, se o identificador j� estiver sendo usado.
	 */
	public Symbol_Class addSymbolClass(String name, ClassType type);
	
	/**
	 * Adiciona declara��o de classe/tipo no ambiente corrente,
	 * para os casos em que uma nova classe est� sendo criada.
	 * @param name Nome da classe.
	 * @return S�mbolo adicionado; ou null, se o identificador j� estiver sendo usado.
	 */
	public Symbol_Class addSymbolClass(String name);
	
	/**
	 * Adiciona declara��o de constante no ambiente corrente.
	 * @param name Nome da constante.
	 * @param type Tipo associado.
	 * @param value Valor da constante.
	 * @return S�mbolo adicionado; ou null, se o identificador j� estiver sendo usado.
	 */
	public Symbol_Constant addSymbolConstant(String name, SemanticType type, Object value);

	/**
	 * Tipo escalar "char".
	 * @return Refer�ncia ao tipo escalar, para ser usado em declara��es.
	 */
	public CharType getCharType();

	/**
	 * Tipo escalar "void".
	 * @return Refer�ncia ao tipo escalar, para ser usado em declara��es.
	 */
	public VoidType getVoidType();

	/**
	 * Tipo escalar "int".
	 * @return Refer�ncia ao tipo escalar, para ser usado em declara��es.
	 */
	public IntegerType getIntegerType();

	/**
	 * Tipo escalar "float".
	 * @return Refer�ncia ao tipo escalar, para ser usado em declara��es.
	 */
	public FloatType getFloatType();

	/**
	 * Tipo escalar "null".
	 * @return Refer�ncia ao tipo escalar.
	 */
	public NullType getNullType();
	
}
