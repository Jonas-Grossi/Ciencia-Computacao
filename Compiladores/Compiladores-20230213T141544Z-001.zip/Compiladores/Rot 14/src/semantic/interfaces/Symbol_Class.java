package semantic.interfaces;

public interface Symbol_Class
extends SemanticSymbol {
	
}
