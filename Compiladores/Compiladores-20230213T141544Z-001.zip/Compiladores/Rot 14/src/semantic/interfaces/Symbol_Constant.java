package semantic.interfaces;

public interface Symbol_Constant
extends SemanticSymbol {
	
	Object getValue();

}
