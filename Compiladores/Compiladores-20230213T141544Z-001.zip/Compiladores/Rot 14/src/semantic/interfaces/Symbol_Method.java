package semantic.interfaces;

public interface Symbol_Method
extends SemanticSymbol {

}
