package semantic.interfaces;

public interface Symbol_Variable
extends SemanticSymbol {
	
	public int getLevel();

	public int getOffset();

}
