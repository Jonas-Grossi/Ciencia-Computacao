package semantic.interfaces;

public interface VoidType
extends ScalarType {

}
