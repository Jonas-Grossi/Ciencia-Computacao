/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.FileInputStream;
import java.io.FileReader;

import scanner.Scanner;
import parser.Parser;

/**
 *
 * @author jose
 */
public class Compilador {

    public static void main(String[] args)
	throws Exception {
		FileReader in = new FileReader("teste01.txt");
		Scanner scanner = new Scanner(in);
		Parser parser = new Parser(scanner);
		parser.parse();
	}

}
