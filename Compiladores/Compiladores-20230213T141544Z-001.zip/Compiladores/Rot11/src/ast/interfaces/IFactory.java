package ast.interfaces;

public interface IFactory {
	
	IIntegerNumber createIntegerNumber(int i);
	IUnaryOperation createUnaryOperation(int code, IExpression operand);
	IBinaryOperation createBinaryOperation(int code, IExpression operand1, IExpression operand2);

}
