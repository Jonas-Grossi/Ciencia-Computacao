package main;

import ast.impl.Factory;
import java.io.FileReader;

import scanner.Scanner;
import parser.Parser;
import ast.interfaces.*;

public class Piloto {

    public static void main(String[] args) throws Exception {
        FileReader in = new FileReader("teste.txt");
        Scanner scanner = new Scanner(in);
        Parser parser = new Parser(scanner, new Factory());
        try {
            Object obj = parser.parse().value;
            System.out.println("Entrada sem erros de sintaxe!");
           
            
            if( obj != null){
                IExpression e = (IExpression) obj;
                PrinterVisitor pv = new PrinterVisitor(System.out);
                e.accept(pv);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }   
}
