package main;

import ast.interfaces.*;
import ast.impl.*;

public class Piloto2 {

    public static void main(String[] args) {
        // Cria uma fábrica
        Factory fac = new Factory();
 // Usa a fábrica para criar uma AST que representa
        // a expressão: 1+2
        IIntegerNumber i1 = fac.createIntegerNumber(1);
        IIntegerNumber i2 = fac.createIntegerNumber(2);
        IBinaryOperation op = fac.createBinaryOperation(parser.SymbolCodes.PLUS, i1, i2);
 // Dispara um visitor de impressão sobre a AST criada
        // (esse Visitor às vezes imprime parêntesis desnecessários)
        PrinterVisitor pv = new PrinterVisitor(System.out);
        op.accept(pv);
    }
}
