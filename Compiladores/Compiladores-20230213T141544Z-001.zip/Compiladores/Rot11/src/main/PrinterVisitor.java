package main;

import java.io.PrintStream;
import parser.SymbolCodes;
import ast.interfaces.*;

public class PrinterVisitor
implements IVisitor {

	private PrintStream out;
		
	public PrinterVisitor(PrintStream out) {
		this.out = out;
	}
	public void visitIntegerNumber(IIntegerNumber inteiro, int i) {
		out.print(inteiro.getValue());
	}
        /*
	public String codeToString(int code) {
		String s = "";
		switch (code) {
		case SymbolCodes.DIVIDE:
			s = "DIV";
			break;
		case SymbolCodes.PLUS:
			s = "SUM";
			break;
		case SymbolCodes.MINUS:
			s = "-";
			break;
		case SymbolCodes.TIMES:
			s = "MULT";
			break;
		}
		return s;
	}
        */
        public String codeToString(int code) {
		String s = "";
		switch (code) {
		case SymbolCodes.DIVIDE:
			s = "/";
			break;
		case SymbolCodes.PLUS:
			s = "+";
			break;
		case SymbolCodes.MINUS:
			s = "-";
			break;
		case SymbolCodes.TIMES:
			s = "*";
			break;
		}
		return s;
	}
	
	public void visitBinaryOperation(IOperation operation, int i) {
                //String op = codeToString(operation.getCode()); 
		if (i == 0) {
                        if(codeToString(operation.getCode()).equals("/")){
                            out.print("[");
                        }else{
                            out.print(/*op+*/"(");
                        }
		} else if (i == 1) { //AQUI QUE ELE JOGA O 1+2, ai no i==0 abre o ( e no i==2 ele fecha ) e no i==1 joga a expressao
			out.print(codeToString(operation.getCode()));
                        //out.print(",");
		} else if (i == 2) {
                        if(codeToString(operation.getCode()).equals("/")){
                            out.print("]");
                        }else{
                            out.print(")");
                        }
		}
	}
        // IGUAL O BINARY SO QUE SO TEM 2 parametros
	public void visitUnaryOperation(IOperation operation, int i) {
		if (i == 0) {
			out.print("(" + codeToString(operation.getCode()));
		} else if (i == 1) {
			out.print(")");
		} 
	}
}
