package main;

import java.io.FileInputStream;

import erros.ListaErros;
import ast.interfaces.Program;
import scanner.Scanner;
import parser.Parser;

public class Piloto {

	public static void main(String[] args) throws Exception {
		FileInputStream in = new FileInputStream("teste.txt");
		ListaErros erros = new ListaErros();
		Scanner scanner = new Scanner(in, erros);
		Parser parser = new Parser(scanner, new ast.impl.Factory(),
				new semantic.impl.SemanticFactory());
		try {
			Object obj = parser.parse().value;
			if (obj != null) {
				Program p = (Program) obj;
				PrinterVisitor pv = new PrinterVisitor(System.out);
				p.accept(pv);
				
				if (erros.tamanho() == 0) {
					System.out.println("Arquivo sem erros de sintaxe!");
				} else {
					System.out.println("Erros encontrados:");
					erros.dump();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
