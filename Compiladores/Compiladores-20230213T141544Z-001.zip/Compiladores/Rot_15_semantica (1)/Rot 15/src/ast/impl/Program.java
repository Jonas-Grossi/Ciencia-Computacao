package ast.impl;

import ast.interfaces.Visitor;

public class Program implements ast.interfaces.Program {

	private ast.interfaces.Identifier ident;
	private ast.interfaces.DeclList initDeclList, methodDeclList;
	
	public Program(ast.interfaces.Identifier ident,
			ast.interfaces.DeclList initDeclList,
			ast.interfaces.DeclList methodDeclList) {
		this.ident = ident;
		this.initDeclList = initDeclList;
		this.methodDeclList = methodDeclList;
	}
	
	public ast.interfaces.Identifier getIdent() {
		return ident;
	}
	
	public ast.interfaces.DeclList getInitDeclList() {
		return initDeclList;
	}
	
	public ast.interfaces.DeclList getMethodDeclList() {
		return methodDeclList;
	}
	
	public void accept(Visitor visitor) {
		visitor.visitProgram(this, 0);
		if (initDeclList != null) initDeclList.accept(visitor);
		visitor.visitProgram(this, 1);
		if (methodDeclList != null) methodDeclList.accept(visitor);
		visitor.visitProgram(this, 2);
	}

}
