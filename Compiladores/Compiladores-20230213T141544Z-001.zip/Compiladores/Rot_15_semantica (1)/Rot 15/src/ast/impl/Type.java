package ast.impl;

import ast.interfaces.Visitor;

public class Type implements ast.interfaces.Type {

	private ast.interfaces.Identifier ident;
	
	public void accept(Visitor visitor) {
		visitor.visitType(this, 0);
		if (ident != null) ident.accept(visitor);
		visitor.visitType(this, 1);
	}

	public ast.interfaces.Identifier getIdent() {
		return ident;
	}

	public void setIdent(ast.interfaces.Identifier ident) {
		this.ident = ident;
	}

	public Type(ast.interfaces.Identifier ident) {
		super();
		this.ident = ident;
	}


}
