package ast.impl;

import ast.interfaces.Visitor;

public class UnaryOperation
extends Operation
implements ast.interfaces.UnaryOperation {

	private ast.interfaces.Expression operand;
	
	public UnaryOperation(int code, ast.interfaces.Expression operand) {
		super(code);
		this.operand = operand;
	}
	
	public ast.interfaces.Expression getOperand() {
		return operand;
	}
	
	public void accept(Visitor visitor) {
		visitor.visitUnaryOperation(this, 0);
		if (operand != null) operand.accept(visitor);
		visitor.visitUnaryOperation(this, 1);
	}


}
