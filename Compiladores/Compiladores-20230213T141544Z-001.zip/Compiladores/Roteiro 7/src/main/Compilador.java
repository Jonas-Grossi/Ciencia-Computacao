/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.FileInputStream;

import scanner.Scanner;
import parser.Parser;

/**
 *
 * @author jose
 */
public class Compilador {

    public static void main(String[] args)   
      throws Exception {
        FileInputStream in = new FileInputStream("teste01.txt");
        Scanner scanner = new Scanner(in);
        
        Parser parser = new Parser(scanner);
        try {
            parser.parse();
            System.out.println("Arquivo sem erros de sintaxe!");
        } catch (Exception e) {
            System.out.println("Erro de sintaxe:" + e);
        }
    }

}
