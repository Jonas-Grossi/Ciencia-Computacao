package erros;

import java.util.ArrayList;

public class ListaErros {

    private ArrayList<Erro> erros = null;
    private Integer quantidadeErros;

    public ListaErros() {
        erros = new ArrayList<Erro>();
        quantidadeErros = 0;
    }

    public int tamanho() {
        return quantidadeErros;
        // ou senao: return erros.size();
    }

    public void defineErro(int linha, int coluna, String texto) {
        Erro e = new Erro(linha, coluna, texto);
        erros.add(e);
        quantidadeErros++;
    }

    //sobrecarga do metodo defErro
    public void defineErro(int linha, int coluna) {
        Erro e = new Erro(linha, coluna);        
        erros.add(e);
        quantidadeErros++;
    }

    //sobrecarga do metodo defErro
    public void defineErro(String texto) {
        for (int i = quantidadeErros - 1; i >= 0; --i) {
            Erro e = erros.get(i);
            if (e.texto == null) {
                e.texto = texto;
                return;
            }
        }
    }

    public void imprimirErros() {
        for (int i = 0; i < quantidadeErros; ++i) {
            Erro e = erros.get(i);
            e.imprime();            
        }
    }
        

}
