package ast.impl;

import ast.interfaces.*;

public class BinaryOperation
        extends Operation
        implements IBinaryOperation {

    private IExpression operand1, operand2;

    public BinaryOperation(int code, IExpression operand1, IExpression operand2) {
        super(code);
        this.operand1 = operand1;
        this.operand2 = operand2;
    }

    public IExpression getOperand1() {
        return operand1;
    }

    public IExpression getOperand2() {
        return operand2;
    }

    public void accept(IVisitor visitor) {
        visitor.visitBinaryOperation(this, 0);
        if (operand1 != null) {
            operand1.accept(visitor);
        }
        visitor.visitBinaryOperation(this, 1);
        if (operand2 != null) {
            operand2.accept(visitor);
        }
        visitor.visitBinaryOperation(this, 2);
    }

}
