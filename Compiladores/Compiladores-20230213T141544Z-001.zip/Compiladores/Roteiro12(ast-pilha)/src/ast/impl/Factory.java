package ast.impl;

import ast.interfaces.*;

public class Factory implements IFactory {

    public Factory() {
    }

    public ast.interfaces.IIntegerNumber createIntegerNumber(int i) {
        return new IntegerNumber(i);
    }

    public IUnaryOperation createUnaryOperation(int code, IExpression operand) {
        return new UnaryOperation(code, operand);
    }

    public IBinaryOperation createBinaryOperation(int code,
            IExpression operand1, IExpression operand2) {
        return new BinaryOperation(code, operand1, operand2);
    }

}
