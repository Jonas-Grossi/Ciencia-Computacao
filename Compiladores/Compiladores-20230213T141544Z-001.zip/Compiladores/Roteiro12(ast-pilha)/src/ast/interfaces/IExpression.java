package ast.interfaces;

public interface IExpression {

	void accept(IVisitor visitor);

}
