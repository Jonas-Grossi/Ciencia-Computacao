package ast.interfaces;

public interface IOperation extends IExpression {

	int getCode();
	
}
