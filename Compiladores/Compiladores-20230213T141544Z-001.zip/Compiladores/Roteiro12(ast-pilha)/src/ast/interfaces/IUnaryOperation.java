package ast.interfaces;

public interface IUnaryOperation extends IOperation {

	IExpression getOperand();
	
}
