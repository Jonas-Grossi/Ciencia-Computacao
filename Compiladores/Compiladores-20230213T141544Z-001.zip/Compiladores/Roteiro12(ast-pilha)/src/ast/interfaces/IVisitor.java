package ast.interfaces;

public interface IVisitor {

	void visitBinaryOperation(IOperation operation, int i);
	void visitIntegerNumber(IIntegerNumber integerNumber, int i);
	void visitUnaryOperation(IOperation operation, int i);

}
