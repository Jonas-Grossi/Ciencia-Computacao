package main;

import java.io.FileInputStream;

import ast.interfaces.IExpression;
import scanner.Scanner;
import parser.Parser;

public class Piloto {

	public static void main(String[] args) throws Exception {
		FileInputStream in = new FileInputStream("teste.txt");
		Scanner scanner = new Scanner(in);
		Parser parser = new Parser(scanner, new ast.impl.Factory());
		try {
			Object obj = parser.parse().value;
			System.out.println("Arquivo sem erros de sintaxe!");
			if (obj != null) {
				IExpression e = (IExpression) obj;
				PrinterVisitor pv = new PrinterVisitor(System.out);
				e.accept(pv);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
