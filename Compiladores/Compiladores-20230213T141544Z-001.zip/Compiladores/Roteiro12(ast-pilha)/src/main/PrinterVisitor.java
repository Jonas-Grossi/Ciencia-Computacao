package main;

import java.io.PrintStream;
import parser.SymbolCodes;
import ast.interfaces.*;

public class PrinterVisitor
implements IVisitor {

	private PrintStream out;
		
	public PrinterVisitor(PrintStream out) {
		this.out = out;
	}
	public void visitIntegerNumber(IIntegerNumber inteiro, int i) {
		out.print(inteiro.getValue());
	}

	public String codeToString(int code) {
		String s = "";
		switch (code) {
		case SymbolCodes.DIVIDE:
			s = "/";
			break;
		case SymbolCodes.PLUS:
			s = "+";
			break;
		case SymbolCodes.MINUS:
			s = "-";
			break;
		case SymbolCodes.TIMES:
			s = "*";
			break;
		}
		return s;
	}
	
	public void visitBinaryOperation(IOperation operation, int i) {
		if (i == 0) {
			out.print("(");
		} else if (i == 1) {
			out.print(codeToString(operation.getCode()));
		} else if (i == 2) {
			out.print(")");
		} 
	}

	public void visitUnaryOperation(IOperation operation, int i) {
		if (i == 0) {
			out.print("(" + codeToString(operation.getCode()));
		} else if (i == 1) {
			out.print(")");
		} 
	}

}
