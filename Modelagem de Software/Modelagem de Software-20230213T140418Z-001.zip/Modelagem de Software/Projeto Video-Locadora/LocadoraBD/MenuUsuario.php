<HTML>
<html>
<HEAD>
 <TITLE>MenuUsuario</TITLE>
 <link rel="stylesheet" type="text/css" href="style.css">
</HEAD>
<BODY>
 <table border=4% width= 100% bordercolor= white background= black>
      <tr>
         <td>
         <ul id="menu">

         <li>
            <div align="center"><font><b>FILMES </b></font>
            <a href="MostrarListFilme.php" title="meu link">Mostrar lista</a>
            <a href="MostrarCatFilme.php" title="meu link">Mostrar Filme e Categoria</a>
         </li>

         <li>

            <div align="center"><font><b>ATORES </b></font>
            <a href="MostrarInfoAtor.php" title="meu link">Informa��es</a>
            <a href="AtorFilme.php" title="meu link">Ator e filmes</a>

         </li>

         <li>

            <div align="center"><font><b>CLASSIFICA��O</b></font>
            <a href="ClassComedia.php" title="meu link">Com�dia</a>
            <a href="ClassDrama.php" title="meu link">Drama</a>

         </li>
         </ul>


	 </td>

      </tr>

</table>
</body>
</html>


