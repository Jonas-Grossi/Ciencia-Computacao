<HTML>
<HEAD>
   <TITLE>Locadora</TITLE>
   <link rel="stylesheet" type="text/css" href="style.css">
</HEAD>
<BODY>
   <table width = 100% height = 20% border =  "1" bgcolor = "#006600" bordercolor = white>
   <td>
   <div align="center"><font size="10" color = white ><b>NetMovies Locadora </b></font></div>
   </td>
   <table width =100% height =80% border = "4" bordercolor = white bgcolor = "#00FFCC">
   <td>
   <div align="center"><font color=black size="7" ><b>Seja bem vindo!!! </b></p></font>
   <BR>

         <ul id="botao">
         <li>
         <a href="MenuAdmin.php" title="meu link"><p align="center"><font size="3" color = white >Administracao</a></p> </font>
         </li>
         </ul>
         <BR><BR><BR>
         <ul id="botao">
         <li>
         <a href="MenuUsuario.php" title="meu link"><font size="3" color = white >Usuario</a></p> </font></div>
         </li>
         </ul>

   </td>

</BODY>
</HTML>
