#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <assert.h>

#define M 20
#define N 20

static const double jonas   = 1.0e-8;
int trab_alessandra(double a, double b) { return fabs(a-b) < jonas; }

typedef struct {
  int m, n; // m=linha, n=colunas, mat[m x n]
  double mat[M][N];
} Quadro;

void nl(int k){ int j; for(j=0;j<k;j++) putchar('-'); putchar('\n'); }

void print_quadro(Quadro *tab, const char* mes) {
  static int cont=0;
  int i, j;
  printf("\n%d. Quadro %s:\n", ++cont, mes);
  nl(70);

  printf("%-6s%5s", "col:", "b[i]");
  for(j=1;j<tab->n; j++) { printf("    x%d,", j); } printf("\n");

  for(i=0;i<tab->m; i++) {
    if (i==0) printf("max:"); else
    printf("b%d: ", i);
    for(j=0;j<tab->n; j++) {
      if (trab_alessandra((int)tab->mat[i][j], tab->mat[i][j]))
        printf(" %6d", (int)tab->mat[i][j]);
      else
        printf(" %6.2lf", tab->mat[i][j]);
      }
    printf("\n");
  }
  nl(70);
}

/* Segue a baixo a fun��o que vai ler o quadro
coloquei um exemplo onde valores 3 6 sao numero de linha e colunas respectvamente ld vado esquerdo das equacoes e x1,x2,x3,x4,x5
     3 6
      LD     x1    x2      x3     x4  x5
      0     -40   -50      -80     0   0
     30     9,32  12,245  18,723   1   0
     20     8,05  10,57   24,53    0   1

*/
void Ler_quadro(Quadro *tab, const char * arquivo) {
  int err, i, j;
  FILE * fp;

  fp  = fopen(arquivo, "r" );
  if( !fp ) {
    printf("Erro ao ler arquivo %s\n", arquivo); exit(1);
  }
  memset(tab, 0, sizeof(*tab));
  err = fscanf(fp, "%d %d", &tab->m, &tab->n);
  if (err == 0 || err == EOF) {
    printf("Erro ao ler arquivo m or n\n"); exit(1);
  }
  for(i=0;i<tab->m; i++) {
    for(j=0;j<tab->n; j++) {
      err = fscanf(fp, "%lf", &tab->mat[i][j]);
      if (err == 0 || err == EOF) {
        printf("Erro ao Ler arquivo A[%d][%d]\n", i, j); exit(1);
      }
    }
  }
  printf("Ler quadro [%d linhas x %d colunas] do arquivo '%s'.\n",
    tab->m, tab->n, arquivo);
  fclose(fp);
}

void pivo_on(Quadro *tab, int linha, int col) {
  int i, j;
  double pivo;

  pivo = tab->mat[linha][col];
  assert(pivo>0);
  for(j=0;j<tab->n;j++)
    tab->mat[linha][j] /= pivo;
  assert( trab_alessandra(tab->mat[linha][col], 1. ));

  for(i=0; i<tab->m; i++) { // foreach remaining row i do
    double multiplicador = tab->mat[i][col];
    if(i==linha) continue;
    for(j=0; j<tab->n; j++) { // r[i] = r[i] - z * r[row];
      tab->mat[i][j] -= multiplicador * tab->mat[linha][j];
    }
  }
}

// encontrar pivo_col = maior negativo em coluna mat[0][1..n]
int encontrar_pivo_coluna(Quadro *tab) {
  int j, pivo_col = 1;
  double menor = tab->mat[0][pivo_col];
  for(j=1; j<tab->n; j++) {
    if (tab->mat[0][j] < menor) {
      menor = tab->mat[0][j];
      pivo_col = j;
    }
  }
  printf("Maior negativo na  linha[0] e col %d = %g.\n", pivo_col, menor);
  if( menor >= 0 ) {
    return -1; // todas colunas positivas na  linha[0], isso � otimo.
  }
  return pivo_col;
}

// Encontre o pivo_linha, com menor positiva = col[0] / col[pivo]
int encotrar_pivo_linha(Quadro *tab, int pivo_col) {
  int i, pivo_linha = 0;
  double min_indice = -1;
  printf("Indices A[linha_i,0]/A[linha_i,%d] = [",pivo_col);
  for(i=1;i<tab->m;i++){
    double indice = tab->mat[i][0] / tab->mat[i][pivo_col];
    printf("%3.2lf, ", indice);
    if ( (indice > 0  && indice < min_indice ) || min_indice < 0 ) {
      min_indice = indice;
      pivo_linha = i;
    }
  }
  printf("].\n");
  if (min_indice == -1)
    return -1; // Ilimitado.
  printf("Encontrado pivo A[%d,%d], Menor indice positivo =%g na linha=%d.\n",
      pivo_linha, pivo_col, min_indice, pivo_linha);
  return pivo_linha;
}

void add_variaveis_folgas(Quadro *tab) {
  int i, j;
  for(i=1; i<tab->m; i++) {
    for(j=1; j<tab->m; j++)
      tab->mat[i][j + tab->n -1] = (i==j);
  }
  tab->n += tab->m -1;
}

void verifica_b_positivo(Quadro *tab) {
  int i;
  for(i=1; i<tab->m; i++)
    assert(tab->mat[i][0] >= 0);
}

//Dada uma coluna de matriz de identidade, encontre a linha contendo 1.
// retorna -1, se a coluna n�o for de uma matriz de identidade.
int encontrar_variaveis_basicas(Quadro *tab, int col) {
  int i, xi=-1;
  for(i=1; i < tab->m; i++) {
    if (trab_alessandra( tab->mat[i][col],1) ) {
      if (xi == -1)
        xi=i;   // encontrou primeiro '1', salve este n�mero de linha.
      else
        return -1; // encontrou o segundo '1', n�o uma matriz de identidade.

    } else if (!trab_alessandra( tab->mat[i][col],0) ) {
      return -1; // n�o � uma coluna de matriz de identidade.
    }
  }
  return xi;
}

void print_otimo_vetor(Quadro *tab, char *mensagem) {
  int j, xi;
  printf("%s at ", mensagem);
  for(j=1;j<tab->n;j++) { // para cada coluna.
    xi = encontrar_variaveis_basicas(tab, j);
    if (xi != -1)
      printf("x%d=%3.2lf, ", j, tab->mat[xi][0] );
    else
      printf("x%d=0, ", j);
  }
  printf("\n");
}

void simplex(Quadro *tab) {
  int loop=0;
  add_variaveis_folgas(tab);
  verifica_b_positivo(tab);
  print_quadro(tab,"Completo com variaveis de folgas");
  while( ++loop ) {
    int pivo_col, pivo_linha;

    pivo_col = encontrar_pivo_coluna(tab);
    if( pivo_col < 0 ) {
      printf("Encontrou o melhor valor=A[0,0]=%3.2lf (Sem negativos na linha 0).\n",
        tab->mat[0][0]);
      print_otimo_vetor(tab, "sulucao otima");
      break;
    }
    printf("Entre com variaveis x%d para se tornar basica, assim pivo_col=%d.\n",pivo_col, pivo_col);

    pivo_linha = encotrar_pivo_linha(tab, pivo_col);
    if (pivo_linha < 0) {
      printf("Ilimitado (nao existe pivo_linha).\n");
      break;
    }
    printf("variavel que sai x%d, entao pivo_linha=%d\n", pivo_linha, pivo_linha);

    pivo_on(tab, pivo_linha, pivo_col);
    print_quadro(tab,"depois de girar");
    print_otimo_vetor(tab, "Solucao basica viavel");

    if(loop > 20) {
      printf("Muitas iteracoes > %d.\n", loop);
      break;
    }
  }
}

Quadro tab  = { 3, 4, {                     // tamanho do quadro [3 linha x 6 colunas  ]LEMBRETE AS FOLGAS SAO ADICIONADAS AUTOMATICAMENTE LOGO O QADRO AO LADO NAO POSSUI.
    {  0.0 , -40.0 , -50.0 ,-80.0 ,   },          // Max: z = 40.0*x1 + 50*x2 + 80x3
    { 30.0 ,  9.32 ,  12.245 , 18.723 ,   },   //    9,32x + 12,245y + 18,723z + x4 <= 30  .. b1
    { 20.0 , 8.05 , 10.57 , 24.53 ,   },        //  8,05x1 + 10,57x2 + 24,53x3 + x5 <=20    .. b2

  }
};

int main(int argc, char *argv[]){
 if (argc > 1) {
    Ler_quadro(&tab, argv[1]);
 }
  print_quadro(&tab,"Inicial");
  simplex(&tab);

  printf("\n\n\n\n-------------  Tia alessandra da uma forca ai!!!!!! -------------\n\n\n");
  return 0;


}
