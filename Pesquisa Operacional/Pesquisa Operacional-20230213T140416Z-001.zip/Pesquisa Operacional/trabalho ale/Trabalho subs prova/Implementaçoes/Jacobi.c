#include<stdio.h>
#include<math.h>
int main() {
int i,j,m,n,l;
float x[10],a[10][10],b[10],soma[10];
printf("\nDigite o numero de variaveis: \n");
scanf("%d",&n);
printf("\nDigite o numero de iteracoes: \n");
scanf("%d",&l);
printf("\nDigite o ponto inicial: \n");
for(i=0;i<n;i++) {
scanf("%f",&x[i]);
}
printf("\nDigite os termos independentes: \n");
for(i=0;i<n;i++) {
scanf("%f",&b[i]);
}
printf("\nDigite a matriz dos coeficientes: \n");
for(i=0;i<n;i++) {
for(j=0;j<n;j++) {
scanf("%f",&a[i][j]);
}
}
m=1;
while(m<=l) {
for(i=0;i<n;i++) {
soma[i]=b[i];
for(j=0;j<n;j++) {
if(i!=j) {
soma[i]=soma[i]-a[i][j]*x[j];
}
}
}
for(i=0;i<n;i++) {
x[i]=soma[i]/a[i][i];
}
m++;
}
printf("\nA solucao do sistema e: \n");
for(i=0;i<n;i++) {
printf("\nx(%d) = %f\n",i,x[i]);
}
}
