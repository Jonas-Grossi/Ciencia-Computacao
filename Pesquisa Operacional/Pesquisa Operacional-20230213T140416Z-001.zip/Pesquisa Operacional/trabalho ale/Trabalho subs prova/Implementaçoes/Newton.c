#include<stdio.h>
#include<math.h>

int main() {

int l,m;

float x,y;

printf("\nDigite o numero de iteracoes: \n");

scanf("%d",&l);

printf("\nDigite o x inicial: \n");

scanf("%f",&x);

printf("\nDigite o y inicial: \n");

scanf("%f",&y);

m=1;

while(m<=l) {

x=(2*pow(x,2)+5)/(4*x);

y=(2*pow(y,2)+3)/(4*y);

m++;

}

printf("\nA solucao do sistema e: \n");

printf("\nx = %f\n",x);

printf("\ny = %f\n",y);

}

