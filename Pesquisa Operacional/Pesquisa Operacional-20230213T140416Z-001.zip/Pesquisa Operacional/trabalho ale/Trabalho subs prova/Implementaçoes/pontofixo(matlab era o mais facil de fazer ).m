%%%%%%%%%%%%%%%%%%%%F2NUM - Calculo Numerico%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-------------------- ZEROS DE FUNCOES REAIS ------------------------------
%                       M�todo do Ponto Fixo                             %
% Profa. Dra. Mariana PMA Baroni

% Objetivo: Dada uma funcao continua num intervalo [a,b] que contem uma raiz
% f(x)=0, a transformaremos em uma equa��o equivalente x=P(x) e gerar uma
% sequ�ncia de aproxima�oes para xb.

% A funcao foi definida usanso syms
% f(x) = x*x + log(x)
% funcao de iteracao = e^(-x^2)

clear all
clc
%Funcao
syms x;
ff=x*x+log(x);
% ---Parametros
epsilon1 = 0.01; %tolerancia
epsilon2 = epsilon1;
%intervalo
x0=0.5; %x0
xb=x0;
%iteracoes
k=0;
kf=1000;

tic
for i=1:kf %kf tb e criterio de parada
    if (abs(subs(ff,x,x0))<epsilon1)
        xb=x0;
        break
    else
        x1=exp(-(x0*x0));
        if (abs(subs(ff,x,x1))<epsilon1 & abs(x1-x0)<epsilon2)
            xb=x1
            break
        else
            x0=x1;
            k=k+1;
        end
    end
end    
toc
sprintf('x = %f',xb) %mostre x
sprintf('f(x) = %f',subs(ff,x,xb)) %mostre y
sprintf('|x1-x0| = %f',abs(x1-x0)) %mostre o intervalo
sprintf('N�mero de iteracoes ate atingir o resultado: %d',k) %mostre iteracoes