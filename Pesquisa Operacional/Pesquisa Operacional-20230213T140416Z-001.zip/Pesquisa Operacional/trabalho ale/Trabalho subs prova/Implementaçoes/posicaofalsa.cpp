#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float f(float x)
{
    float y;
    y = pow(x,3)-x-4;
    return y;
}

float posicfal(float a, float b, float tol)
{
    float fa,fb,c,fc;
    fa=f(a);
    fb=f(b);
    c = (b*f(a)-f(b)*a)/(f(a)-f(b));
    fc=f(c);
    while(fabs(f(c))>tol)
    {
        c = (b*f(a)-f(b)*a)/(f(a)-f(b));
        fc=f(c);
        if(fa*fc<0)
        {
            b=c;
            fb=fc;
        }
        else
        {
            a=c;
            fa=fc;
        }
    }

    return c;
}

int main()
{
    float a,b,tol,c;
    printf("Metodo da Posicao Falsa.\n");
    printf("a =");
    scanf("%f",&a);
    printf("b =");
    scanf("%f",&b);
    printf("erro =");
    scanf("%f",&tol);
    c = posicfal(a,b,tol);
    printf("Raiz aproximada = %0.4f \n",c);
    system("pause");
    return 0;
}


