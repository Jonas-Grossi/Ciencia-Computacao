/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author gilso
 */
public class MochilaDin {

    private int[] vetPeso;
    private int[] vetValores;
    private int[][] matrizTabela;
    private int itens;
    private int capacidade;

    public MochilaDin(int[] vetPeso, int[] vetValores, int itens, int capacidade) {
        vetPeso = new int[vetPeso.length];
        vetValores = new int[vetValores.length];
        matrizTabela = new int[itens+1][capacidade+1];
        this.vetPeso = vetPeso;
        this.vetValores = vetValores;
        this.capacidade = capacidade;
        this.itens = itens;
    }
    
    public int calcMochila(int vetPeso[], int vetValores[]){
        int b;
        int aux;
        for(int i = 0; i <= capacidade; i++){
            matrizTabela[0][i] = 0;
            for(int k = 1; k <= itens; k++){
                 aux = matrizTabela[k-1][i];
                if(vetPeso[k-1] > i){ //
                    b = 0;
                }else{
                  b = matrizTabela[k-1][i-vetPeso[k-1]] + vetValores[k-1];;
                }if(aux > b){
                    matrizTabela[k][i] = aux;
                }else{
                    matrizTabela[k][i] = b;
                }
            }
        }
        
        return matrizTabela[itens][capacidade];
    }
    
    public void imprimir(){
        for(int i = 0; i <= itens; i++){
            for(int k = 0; k <= capacidade; k++){
                System.out.print(matrizTabela[i][k] + "\t " );
            }
            System.out.println();
        }
    }
    

    /**
     * @return the vetPeso
     */
    public int[] getVetPeso() {
        return vetPeso;
    }

    /**
     * @param vetPeso the vetPeso to set
     */
    public void setVetPeso(int[] vetPeso) {
        this.vetPeso = vetPeso;
    }

    /**
     * @return the vetValores
     */
    public int[] getVetValores() {
        return vetValores;
    }

    /**
     * @param vetValores the vetValores to set
     */
    public void setVetValores(int[] vetValores) {
        this.vetValores = vetValores;
    }

    /**
     * @return the matrizTabela
     */
    public int[][] getMatrizTabela() {
        return matrizTabela;
    }

    /**
     * @param matrizTabela the matrizTabela to set
     */
    public void setMatrizTabela(int[][] matrizTabela) {
        this.matrizTabela = matrizTabela;
    }

    /**
     * @return the itens
     */
    public int getItens() {
        return itens;
    }

    /**
     * @param itens the itens to set
     */
    public void setItens(int itens) {
        this.itens = itens;
    }

    /**
     * @return the capacidade
     */
    public int getCapacidade() {
        return capacidade;
    }

    /**
     * @param capacidade the capacidade to set
     */
    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }
}
