/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author pafon
 */
public class MochilaProgramaçaoDinamica {

    private int capacidadeMaxima;
    private int quantidadeProduto;
    private int[] peso;
    private int[] valor;
    private int[][] matriz;

        public MochilaProgramaçaoDinamica() {
        capacidadeMaxima = 0;
        quantidadeProduto = 0;
        peso = new int[10];
        valor = new int[10];
        matriz = new int[11][11];
        for (int i = 0; i < 10; i++) {
            peso[i] = 0;
            valor[i] = 0;
        }
        for (int i = 0; i < 11; i++) {
            for (int j = 0; j < 11; j++) {
                matriz[i][j] = 0;
            }
        }
    }
     
    public MochilaProgramaçaoDinamica(int capacidadeMaxima, int quantidadeProduto, int[] peso, int[] valor) {
        peso = new int[peso.length];
        valor = new int[valor.length];
        matriz = new int[quantidadeProduto + 1][capacidadeMaxima + 1];

        this.capacidadeMaxima = capacidadeMaxima;
        this.quantidadeProduto = quantidadeProduto;
        this.peso = peso;
        this.valor = valor;

        for (int i = 0; i < quantidadeProduto + 1; i++) {
            for (int j = 0; j < capacidadeMaxima + 1; j++) {
                matriz[i][j] = 0;
            }
        }
    }

    public int preencherMatriz(int peso[], int valor[]) {
        int valor1, valor2;
        this.peso = peso;
        this.valor = peso;

        for (int colunaCapacidade = 0; colunaCapacidade <= capacidadeMaxima; colunaCapacidade++) {
            for (int linhaProduto = 1; linhaProduto <= quantidadeProduto; linhaProduto++) {
                valor2 = matriz[linhaProduto - 1][colunaCapacidade];
                valor1 = verificaValor(linhaProduto - 1, colunaCapacidade);
                matriz[linhaProduto][colunaCapacidade] = maiorValor(valor1, valor2);
            }
        }

        return matriz[quantidadeProduto][capacidadeMaxima];
    }
//indexProduto = k-1 ; capacidadeMaximaAtual = i;

    public int verificaValor(int indexProduto, int colunaCapacidade) {
        if (peso[indexProduto] > colunaCapacidade) {
            return (0);
        } else {

            return (matriz[indexProduto][colunaCapacidade - peso[indexProduto]] + valor[indexProduto]);
        }

    }
    public int maiorValor(int valor1, int valor2) {

        if (valor2 > valor1) {
            return valor2;
        } else {
            return valor1;
        }
    }

    public void tracejar(int n) {
        for (int i = 0; i < n; i++) {
            System.out.print("-");

        }
        System.out.println("|");
    }

    public void imprimir() {
        System.out.print("|");
        tracejar(400);
        for (int i = 0; i <= quantidadeProduto; i++) {
            if (i == 0) {
                for (int j = 0; j <= capacidadeMaxima; j++) {
                    if (j == 0) {
                        System.out.print("| \t\tColuna" + (j) + "\t");
                    }
                    if (j > 0 && j<= capacidadeMaxima-1) {
                        System.out.print("⤵ \t\tColuna" + (j) + "\t");
                    }
                    if(j==capacidadeMaxima){
                        System.out.print("⤵\t\tColuna" + (j) + "⤵");
                    }
                }
                System.out.println("");
            }
            System.out.print("| Linha " + i + ": \t");

            for (int j = 0; j <= capacidadeMaxima; j++) {
                System.out.print("\t" + matriz[i][j] + " \t|\t ");

            }
            System.out.print("\n");
        }
        System.out.print("|");
        tracejar(400);
        
        System.out.println("Complexidade O(n²), um for dentro de outro quando os valores são calculados durante o preenchimento da matriz.");
    }

    /**
     * @return the peso
     */
    public int[] getPeso() {
        return peso;
    }

    /**
     * @param peso the peso to set
     */
    public void setPeso(int[] peso) {
        this.peso = peso;
    }

    /**
     * @return the valor
     */
    public int[] getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(int[] valor) {
        this.valor = valor;
    }

    /**
     * @return the matriz
     */
    public int[][] getMatriz() {
        return matriz;
    }

    /**
     * @param matriz the matriz to set
     */
    public void setMatriz(int[][] matriz) {
        this.matriz = matriz;
    }

    /**
     * @return the quantidadeProduto
     */
    public int getQuantidadeProduto() {
        return quantidadeProduto;
    }

    /**
     * @param quantidadeProduto the quantidadeProduto to set
     */
    public void setQuantidadeProduto(int quantidadeProduto) {
        this.quantidadeProduto = quantidadeProduto;
    }

    /**
     * @return the capacidadeMaxima
     */
    public int getCapacidadeMaxima() {
        return capacidadeMaxima;
    }

    /**
     * @param capacidadeMaxima the capacidadeMaxima to set
     */
    public void setCapacidadeMaxima(int capacidadeMaxima) {
        this.capacidadeMaxima = capacidadeMaxima;
    }
}
