/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mochiladinamica;

import Classes.MochilaProgramaçaoDinamica;

/**
 *
 * @author pafon
 */
public class ClassePrincipal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {       
        int capacidadeMaxima = 15, qtdProduto=4;
        int[] peso = {1, 7, 4, 9};
        int[] valor = {1, 9, 3, 2};
        
        MochilaProgramaçaoDinamica mochila = new MochilaProgramaçaoDinamica(capacidadeMaxima, qtdProduto, peso, valor);
        
        System.out.println("O maior valor obtido sem repetir os produtos da mochila foi:  " + mochila.preencherMatriz(peso,valor));
        
        System.out.println("Resultado: ");
        mochila.imprimir();
    }
    
}
