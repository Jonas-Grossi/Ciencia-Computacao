/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mochiladinamica;

import Classes.MochilaDin;

/**
 *
 * @author gilso
 */
public class MochilaDinamica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {       
        int[] vetPeso = {1, 3, 5};
        int[] vetValores = {3, 8, 5};
        int capacidade = 8;
        MochilaDin mochilaDin = new MochilaDin(vetPeso, vetValores, 3, capacidade);
        
        System.out.println("O valor maximo dos itens da mochila e: " + mochilaDin.calcMochila(vetPeso,vetValores));
        
        System.out.println("Matriz completa: ");
        mochilaDin.imprimir();
    }
    
}
