
package conta_thread;

import java.util.Random;


public class Conta_Thread {
Get_conta s = new Get_conta();
     Random r = new Random();
    public synchronized void realiza_saque() throws InterruptedException{
        
        float sal = s.getSaldo();
        float valor2 = r.nextInt(99);
        if(sal >= valor2){
            
            
            float sal2 = sal - valor2;
            
            s.setSaldo(sal2);
            System.out.println("Sacou "+valor2);
            System.out.println("Saldo "+sal2);
        
        }else{
            
               System.err.println("Saldo Insulficiente para sacar "+ valor2);
               wait();
        }
        
    }
        public synchronized void realiza_deposito(){
        
       
        float valor = r.nextInt(99);
        
        
          
            float novo_saldo = s.getSaldo() + valor;
              System.out.println("Realizou deposito de "+valor);
            
              System.out.println("Saldo "+novo_saldo);           
 
            s.setSaldo(novo_saldo);
           
            notify();
        }
        
    }
    
    

