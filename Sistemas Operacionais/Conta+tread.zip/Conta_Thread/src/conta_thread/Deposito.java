
package conta_thread;


public class Deposito extends Thread {
 
    
 @Override
 public void run(){
    Conta_Thread d = new Conta_Thread();
  
    for(int i=0;i<10;i++){
    
        d.realiza_deposito();
        
    }
    
}
}