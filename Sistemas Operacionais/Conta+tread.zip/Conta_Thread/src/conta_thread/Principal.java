
package conta_thread;


public class Principal {
    public static void main (String[] args) throws InterruptedException{
        Sacar s = new Sacar();
        Deposito d = new Deposito();
        d.start();
        d.join();
        s.start();
        s.join();
        
        
        
    }
}
