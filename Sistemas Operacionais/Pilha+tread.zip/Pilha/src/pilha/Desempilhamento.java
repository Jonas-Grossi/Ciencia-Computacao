
package pilha;

import java.util.logging.Level;
import java.util.logging.Logger;


public class Desempilhamento extends Thread {
    Pilha pilha;
   
   
    @Override
    public void run(){
        for(int i=0;i<10;i++){
            if(!pilha.vazia()){
                try {
                    pilha.desempilha();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Desempilhamento.class.getName()).log(Level.SEVERE, null, ex);
                }
        
            
        
    }
    
}
    }
}