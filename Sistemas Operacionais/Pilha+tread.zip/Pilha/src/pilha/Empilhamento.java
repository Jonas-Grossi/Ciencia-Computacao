

package pilha;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Empilhamento extends Thread{
   Pilha pilha;
   int elemento;
   
   @Override
    public void run(){
      for(int i=0;i<10;i++){ 
          Random r = new Random();
            elemento = r.nextInt(100);
          if(!pilha.cheia()){
              try {
                  pilha.empilha(elemento);
              } catch (InterruptedException ex) {
                  Logger.getLogger(Empilhamento.class.getName()).log(Level.SEVERE, null, ex);
              }
          }
    }
}
}