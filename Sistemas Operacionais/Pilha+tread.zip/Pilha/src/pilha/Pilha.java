
package pilha;


public class Pilha {

    private int topo;
    private final int dados[];
 
   public Pilha(int elemento){
       dados = new int[elemento];
       topo = -1;
       
   }
    public boolean vazia (){
    return (topo == -1 );    
    
    }
public boolean cheia (){
        return (topo == dados.length );
    
}
public synchronized void empilha(int x) throws InterruptedException{
    if(!cheia()){
        topo++;
    dados[topo] = x;
    
    System.out.println("empilhou: "+ dados[topo]);
    notify();
    }else{
        System.out.println("Pilha está cheia");
        wait();
    }
    
}
public synchronized void desempilha() throws InterruptedException{
    if(!vazia()){
        topo --;
        System.out.println("Desempilhou: " + dados[topo+1]);
        notify();
    }else{
        System.out.println("A pilha está vazia");
        wait();
    }
}


}