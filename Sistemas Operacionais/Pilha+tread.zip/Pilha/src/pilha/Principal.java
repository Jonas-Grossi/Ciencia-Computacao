
package pilha;


public class Principal {
    public static void main (String[] args) throws InterruptedException{
        Pilha pilha = new Pilha(10);
        Empilhamento e = new Empilhamento();
        Desempilhamento d = new Desempilhamento();
        e.pilha = pilha;
        d.pilha = pilha;
        e.start();
        d.start();
        e.join();
        d.join();
    }
}
