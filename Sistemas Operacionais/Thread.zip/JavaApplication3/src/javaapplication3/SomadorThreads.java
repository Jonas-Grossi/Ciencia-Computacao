
package javaapplication3;


public class SomadorThreads {

  
    public static void main(String[] args) {
    
        //DECLARA E PREENCHE O VETOR COM OS VALORES ALEATORIOS E EFETUA UMA SOMA PARA SABER SE O RESULTADO BATE
        int[] vetor = new int[10000];
        int cont =0;
        int t = 0;
        for(int i=0; i<10000; i++){
            vetor[i] = i;
            cont += i;
        }
        System.out.println("RESULTADO CORRETO: "+ cont);
        
        
        //DECLARAÇÃO DA THREAD, PASSA O INICIO E O FIME DE CADA PARTE DO VETOR
        somador s1 = new somador();
        s1.inicio = 0;
        s1.fim = vetor.length/4;
        s1.array = vetor;
        
  
        somador s2 = new somador(); 
        s2.inicio = vetor.length/4;
        s2.fim = vetor.length/2;
        s2.array = vetor;

        
        
        somador s3 = new somador(); 
        s3.inicio = vetor.length/2;
        s3.fim = vetor.length - vetor.length/4;
        s3.array = vetor;

        
        
        somador s4 = new somador(); 
        s4.inicio = vetor.length - vetor.length/4;
        s4.fim = vetor.length;
        s4.array = vetor;

        
        
      
        s1.start();
        s2.start();
        s3.start();
        s4.start();
        
        //VERIFICA SE TODAS AS THREADS JA TERMINARAM DE RODAR E EFETUA A SOMA FINAL 
        while ( t == 0){
          if(!s1.isAlive() && !s2.isAlive() && !s3.isAlive() && !s4.isAlive()){
            int soma = s1.c+s2.c+s3.c+s4.c;
            t = -1;
            System.out.println("SOMA THREADS: "+ soma);
            
        }  
        }
        
        
        
        
        
    
    }
    }
    

