/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author aluno
 */
public class contador extends Thread{
    String nome;
    public void run(){
     
        for(int i=0;i<1000;i++){
            System.out.println(nome+":" +i);
            
        }
        
        
    }

    
     public static void main(String[] args) {
     contador c1 = new contador();
     c1.setPriority(Thread.MIN_PRIORITY);
     c1.nome = ("c1");
     
    contador c2 = new contador();
     c2.setPriority(Thread.NORM_PRIORITY);
    c2.nome = ("c2");
     contador c3 = new contador();
     c3.setPriority(Thread.MAX_PRIORITY);
     c3.nome = ("c3");
    c1.start();
    c2.start();
    c3.start();
    
    }
    
}
