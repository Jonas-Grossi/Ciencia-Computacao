/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author aluno
 */
public class somador extends Thread {
    public int c=0;
    public int inicio;
    public int fim;
    public int[] array; 
    
    //Soma os componentes do vetor    
    public void run() {
            for(int i=inicio; i<fim; i++){
               c += array[i];
            } 
    }
    
}
