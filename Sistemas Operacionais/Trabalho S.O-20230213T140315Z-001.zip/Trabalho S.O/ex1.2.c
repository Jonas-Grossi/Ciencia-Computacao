//By Jonas Grossi

#include<stdio.h>
#include<stdlib.h>

int main(){
	int numero;
	
  scanf("%i",&numero);
	

              if(numero % 2 == 0){
		printf("O Numero %i e  PAR",numero);

}else{		
printf("O Numero %i e IMPAR",numero);
	}

	

}
