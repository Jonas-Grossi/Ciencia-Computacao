#include<stdio.h>
#include<stdlib.h>

int main(){
    int n;
    srand(time(NULL));
    n=rand()%999;
    printf("%d\n",n);
    //system("pause");
}

