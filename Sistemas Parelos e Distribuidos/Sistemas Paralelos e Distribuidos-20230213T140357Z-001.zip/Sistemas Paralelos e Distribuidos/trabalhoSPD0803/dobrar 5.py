import threading
import time
import subprocess
import sys

inicio = time.time()

def worker(idThread):



    print("Thread %i comecando\n" % idThread)
    
    p = subprocess.Popen(['./dobrar'],
                   stdin=subprocess.PIPE,
                   stdout=subprocess.PIPE,
                   stderr=subprocess.PIPE,
                   encoding = 'utf8')
    saida = p.communicate("5")

    sys.stdout.write(saida[0]+'Resultado:'+saida[1])    

def exec():
    t=[]
    for i in range(5):



                t = threading.Thread(target=worker, args=(i,))
                t.start()

    while t.isAlive():
               print("Aguardando...")
               time.sleep(0)
    
    print("Acabou!!")
          
exec()


fim = time.time()
tempo = fim - inicio
print("Tempo\n" + str (tempo))
