#include <iostream>
#include <unistd.h>

//Calcula o dobro do no fornecido como entrada
int main(){
    int n;
    std::cin >> n;
    std::cerr << 2*n << '\n';
    std::cout << "Programa em C++: ACABEI!";
    std::cout << "bla";
    usleep(100);
}
