#coding: utf-8
import subprocess
import sys
import time

inicio = time.time()

for i in range(5):
    p = subprocess.Popen(['./dobrar'],
                   stdin=subprocess.PIPE,
                   stdout=subprocess.PIPE,
                   stderr=subprocess.PIPE,
                   encoding = 'utf8')
    saida = p.communicate("8")

    sys.stdout.write(saida[0]+'Resultado:'+saida[1])


fim = time.time()

tempo = fim - inicio
print("Tempo\n" + str (tempo))
