import threading
import time

def worker(idThread):
    print("Thread %i comecando\n" % idThread)
    contador = idThread
    while contador:
        print("Thread %s fazendo o processo %d\n" % (idThread,contador))
        contador -=1

def exec():
    t=[]
    for i in range(5):
                t = threading.Thread(target=worker, args=(i,))
                t.start()

    while t.isAlive():
               print("Aguardando...")
               time.sleep(5)
    
    print("Acabou!!")
            
exec()
