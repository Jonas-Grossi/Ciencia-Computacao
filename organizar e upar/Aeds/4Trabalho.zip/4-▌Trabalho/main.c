
#include <stdio.h>
#include <stdlib.h>
#include "mystring.c"
#define MAX_LINES 20
#define MAX_LINE_CHARS 70


typedef struct {
    int lin;
    int col;
} LinCol;






LinCol proximo_texto(FILE *fp, char *texto, int inicio) {
    LinCol Result;
    int i, pos;

    Result.lin = -1; Result.col = -1;

    while(!feof(fp)){
        for(i = inicio; i < MAX_LINES; i++) {
             if( (mystrlen(texto[i])) > 0) {
                        Result.lin = i;
                        Result.col = pos;
                        return Result;

            }
        }

    }
    return Result;
}


void imprime(FILE *fp, int max_lines) {
    char linha[MAX_LINE_CHARS];
    int i = 0;

    while((!feof(fp)) && (max_lines != -1 ? i < max_lines : 1)) {
        if(fgets(&(*linha), MAX_LINE_CHARS, fp)) {
            if(max_lines != -1) i++;
            printf("%s\n", linha);
        }
        else break;
    }
}


int main(int argc, char *argv[]) {
    FILE *fp;
    //TextoPuro *TP;
    LinCol LC;
    char *texto;
    texto = (char*)malloc(sizeof(char)*MAX_LINE_CHARS);

    if(argc < 2) {
        printf("ERRO 1\n\n");
        exit(1);
    }

    if((fp = fopen(argv[1], "r")) == NULL) {
        printf("ERRO 2\n\n");
        exit(2);
    }

   // le_texto(fp, *TP);
    imprime(fp, -1);

    printf("Texto para pesquisa: ");
    scanf("%s", &texto);
    printf("\nPesquisando %s\n", texto);

    // Encontra todas as ocorrências de texto
    LC = proximo_texto(fp, texto, 0);
    while(LC.lin != -1 && LC.col != -1) {
        printf("Encontrei %s na linha %d, coluna %d.\n", texto, LC.lin, LC.col);
        LC = proximo_texto(fp, texto, LC.lin + 1);
    }

    fclose(fp);

    return 0;
}
