
package javaapplication3;

import java.util.Random;

/**
 *
 * @author jonas
 */
public class random extends Thread {
    String nome;
    public void run(){
     
       int[] numeros = new int[10000];
    Random r = new Random();
    for (int i = 0; i < numeros.length; i++) {
        numeros[i] = (r.nextInt(9));
        System.out.println(nome+":" +numeros[i]); 
    }
   
}
    public static void main(String[] args) {
        random r1 = new random();
     r1.setPriority(Thread.MIN_PRIORITY);
     r1.nome = ("r1");
     
    random r2 = new random();
     r2.setPriority(Thread.NORM_PRIORITY);
     
      r2.nome = ("r2");
    
     random r3 = new random();
    
     r3.setPriority(Thread.MAX_PRIORITY);
     r3.nome = ("r3");
    r1.start();
    r2.start();
    r3.start();
    
    }

    }

